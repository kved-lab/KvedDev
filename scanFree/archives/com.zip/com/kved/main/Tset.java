package com.kved.main;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.xbill.DNS.Address;

public class Tset {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			

		
		
		
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}

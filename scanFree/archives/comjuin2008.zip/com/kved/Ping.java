package com.kved;

import java.net.URL;
import java.util.Date;
import java.util.Properties;

public class Ping {
	final Thread tmain = Thread.currentThread();
	final ThreadGroup urlGroup = new ThreadGroup("urlGroup");
	int maxThread=0;
	final int[] ref = {32, 46, 97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122, 50,51,52,53,54,55,56,57,48,49}; 
	final int refLength=ref.length;
	// mot de depart initialis� � la construction par position dans ref
	int[] mot = {0,0,0,0,0,0,0,0,0,0};
	final int motLength=mot.length;
	char[] data = new char[motLength];
	
	String suffixe=null;
	
	private Ping(){
		Properties props=null;
		int[] motChar = {' ',' ',' ',' ',' ',' ',' ',' ',' ',' '};
		String motStr=null;
		try {
			props = new Properties();
			URL propUrl = ClassLoader.getSystemResource("ping.properties");
			props.load(propUrl.openStream());
			maxThread = Integer.decode((String)props.get("maxThread")).intValue();
			
			System.out.println("maxThread = "+maxThread);
			System.out.println("suffixe = "+props.getProperty("suffixe"));
			System.setProperty("sun.net.client.defaultConnectTimeout", props.getProperty("sun.net.client.defaultConnectTimeout"));
			System.setProperty("sun.net.client.defaultReadTimeout", props.getProperty("sun.net.client.defaultReadTimeout"));
			suffixe=(String)props.get("suffixe");
			motStr = BusinessObjectMysql.getURLbyId(BusinessObjectMysql.getMaxId());

			if (motStr.contains(suffixe))
				motStr=motStr.substring(0, motStr.indexOf(suffixe));
			if (motStr.contains(".neuf.fr"))
				motStr=motStr.substring(0, motStr.indexOf(".neuf.fr"));

			motStr="kvec";
			
			
			System.out.println("Chaine de d�but = "+motStr);

			//init motChar
			if (motStr.length()>motLength)
				throw new Exception("Erreur mot trop long");

			for (int i = 0; i<motStr.length(); i++)
				motChar[motChar.length-i-1] = motStr.charAt(motStr.length()-i-1); 

			// init mot
			try {
				for (int i=0;i<motChar.length;i++) {
					for (int j=0;j<ref.length;j++){
						if ((int)motChar[i]==ref[j]){
							mot[i]=j;
							break;
						}
						else {
							if (j==ref.length-1)
								throw new Exception("motChar incorrecte, caractere non prevu");
						}
					}
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean regleOK(char[] url){
		int deb=0;
		if 	(url[url.length-1]=='.')
			return false;
		if 	(url[0]=='.')
			return false;
		
		for (int i=0;i<url.length;i++)
			if (url[i]!=' '){
				deb =i;
				break;
			}
		
		for (int i=deb;i<url.length;i++)
			if (url[i]==' '){
				return false;
			}
		return true;
	}

	private void incremente(int i){
		if (mot[i]!=refLength-1){
			mot[i]++;
		} else {
			mot[i]=1;
			incremente(i-1);
		}
		data[i]= (char)ref[mot[i]];
	}

	private void cherche() {
		for (int i=0;i<motLength;i++)
			data[i]= (char)ref[mot[i]];
		int h=1;

		StringBuffer urlfree=null;
		//StringBuffer urlneuf=null;
//		long start=new Date().getTime();
		//while ((mot[0]!=ref.length-1 || mot[nbChar-1]!=ref.length-1) ){
		while (true){
			incremente (motLength-1);
			if (regleOK(data)){
				urlfree = new StringBuffer();
				urlfree.append(data);
				urlfree.append(suffixe);
				//System.out.println(urlGroup.activeCount() +" "+urlfree.toString().trim());
				if (urlGroup.activeCount()>maxThread)
					tmain.suspend();
				try {
					//System.out.println(urlb.toString()+" trouv� " +urlGroup.activeCount());
					new URLThread(tmain, urlGroup,urlfree.toString().trim());
				} catch (Exception e) {
					e.printStackTrace();
				}

				// forme incorecte pour lecture url depuis base
//				StringBuffer urlorange = new StringBuffer();
//				urlorange.append("pagesperso-orange.fr/");
//				urlorange.append(data);

//				if (urlGroup.activeCount()>maxThread)
//				tmain.suspend();
//				try {
//				new URLThread(tmain, urlGroup,urlorange.toString().trim());
//				} catch (Exception e) {
//				e.printStackTrace();
//				}

//				urlneuf = new StringBuffer();
//				urlneuf.append(data);
//				urlneuf.append(".neuf.fr");
//				if (urlGroup.activeCount()>maxThread)
//					tmain.suspend();
//				try {
//					new URLThread(tmain, urlGroup,urlneuf.toString().trim());
//				} catch (Exception e) {
//					e.printStackTrace();
//				}

				// redirection vers page alice 404
//				StringBuffer urlalice = new StringBuffer();
//				urlalice.append(data);
//				urlalice.append(".chez-alice.fr");
//				if (urlGroup.activeCount()>maxThread)
//				tmain.suspend();
//				try {
//				new URLThread(tmain, urlGroup,urlalice.toString().trim());
//				} catch (Exception e) {
//				e.printStackTrace();
//				}

				// redirection vers par 410 Gone
//				StringBuffer urlchez = new StringBuffer();
//				urlchez.append("www.chez.com/");
//				urlchez.append(data);
//				if (urlGroup.activeCount()>maxThread)
//				tmain.suspend();
//				try {
//				new URLThread(tmain, urlGroup,urlchez.toString().trim());
//				} catch (Exception e) {
//				e.printStackTrace();
//				}

//				StringBuffer urlclub = new StringBuffer();
//				urlclub.append(data);
//				urlclub.append(".club.fr");
//				if (urlGroup.activeCount()>maxThread)
//				tmain.suspend();
//				try {
//				new URLThread(tmain, urlGroup,urlclub.toString().trim());
//				} catch (Exception e) {
//				e.printStackTrace();
//				}
			}
			//		long stop=new Date().getTime();
			//	h++;

//			System.out.println((float)h*1000/(float)(stop-start+1));
		}
	}

	public static void main(String[] args) {
		Ping ping = new Ping();
		ping.cherche();
	}
}

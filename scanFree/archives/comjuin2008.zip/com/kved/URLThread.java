package com.kved;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Map;

import com.kved.main.SimplifyContent;


public class URLThread implements Runnable{
	private Thread _t;
	private Thread tcherche;
	private String str=null;

	// Constructeur
	URLThread(Thread tcherche,ThreadGroup group, String str) throws Exception {
		this.str="http://"+str;
		this.tcherche = tcherche;
		_t = new Thread(group,this); // instanciation du thread
		_t.start(); // demarrage du thread, la fonction run() est ici lanc�e
	}
	public void run() {

		try {
			MySpider arachnid = new MySpider(str);
			PageInfo pi = arachnid.p;

			Map headerHttp = arachnid.getHeaderHttp();
			//System.out.println("D�but thread "+str);
			//System.out.println(headerHttp);
			String mails="";
			String desc ="";
			String title = "";
			String keyword="";
			String content="";
			String contentType=arachnid.contentType;
			int responseCode=arachnid.responseCode;
			try {
				if (responseCode==200){
					SimplifyContent sc= new SimplifyContent(new URL(str));
					content=sc.convert();
					//System.out.println("content "+content);
					//System.out.println("pi "+pi);
				}
			}catch(Throwable t) {

			}
			if (  pi!=null && pi.isValid()){
				if (pi.getMails() != null) {
					for (int i=0; i<pi.getMails().length; ++i) {
						mails+=pi.getMails()[i];
						if (i<(pi.getMails().length-1)) mails+=", ";
					}
				}
				desc = pi.getDescription();
				if (desc==null) desc="";
				title = pi.getTitle();
				if (title==null) title="";
				keyword=pi.getkeywords();
				if (keyword==null) keyword="";
				contentType=pi.getContentType();
				responseCode = pi.getResponseCode();
				pi.dump();
			}
			if (headerHttp.size()!=0){
				//System.out.println(str);
				BusinessObjectMysql.writeUrl( str.substring(str.indexOf("http://")+7,str.length()),  contentType,  desc,  mails,  responseCode,  keyword,  title, headerHttp.toString(), content);
			}
		} catch (IOException e) {
			// rat�
//			System.out.println("rat�: "+str);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}

		if (tcherche!=null) tcherche.resume();
		//System.out.println("fin thread "+str);
		_t.interrupt();
	}
}


<? if (($pass=="admin")&&($idadmin=="admin")) { 
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

$query="SELECT text_module, nom_fichier_module FROM modules where nom_module='pub'";
$res=mysql_query($query,$db);
$row=mysql_fetch_row($res);
$text=$row[0];
$file=$row[1];

$query="SELECT text_module, nom_fichier_module FROM modules where nom_module='module1'";
$res=mysql_query($query,$db);
$row=mysql_fetch_row($res);
$text1=$row[0];
$file1=$row[1];

$query="SELECT text_module, nom_fichier_module FROM modules where nom_module='module2'";
$res=mysql_query($query,$db);
$row=mysql_fetch_row($res);
$text2=$row[0];
$file2=$row[1];

?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB">
<p align="center"><u>Gestion du module de pub </u></p>

<?
//connection 
// recherche des textes de la base dans $text1, $text2, $text3
?>
Les images sont � coller dans le repertoire ftp://cab-champagne@vin-et-champagne.com/web/site/images_modules/
<br>
<form name="form1" action="Maintenance_images_recept.php">
  <p>Bandeau de Pub:</p>
  <p>Texte : 
    <input type="text" name="text" value="<?echo $text;?>">
  </p>
  <p>Nom du fichier image: 
    <input type="text" name="file"  value="<?echo $file;?>">
  </p>
  <p>&nbsp;</p>
  <p>Module 1:</p>
  <p>Texte : 
    <input type="text" name="text1"  value="<?echo $text1;?>">
  </p>
  <p>Nom du fichier image: 
    <input type="text" name="file1" value="<?echo $file1;?>">
  </p>
  <p>&nbsp;</p>
  <p>Module 2:</p>
  <p>Texte : 
    <input type="text" name="text2" value="<?echo $text2;?>">
  </p>
  <p>Nom du fichier image: 
    <input type="text" name="file2" value="<?echo $file2;?>">
  </p>
  <p>
    <input type="submit" name="Submit" value="Envoyer">
  </p>
  <input type="hidden" name="idadmin" value="<?=$idadmin?>">
  <input type="hidden" name="pass" value="<?=$pass?>">
</form>
<p>&nbsp;</p>
</body>
</html>
<? } else echo "<body bgcolor=\"#C0BCBB\">";?>
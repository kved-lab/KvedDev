<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>formulaire mailing list</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_07.gif" width="237" height="19" alt="" border="0"></td>
</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	<td valign="top"><table border="0" cellspacing="0" cellpadding="3">
		<tr>
			<td valign="top"><br>
<?

$texte = $texte . $Prenom .  " " . $Nom;

$texte = $texte . "\nd�sire s'inscrire � la mailing list de vin-et-champagne.com";


$texte = $texte . "\nAdresse :\n" . $Adresse ;

$texte = $texte . "\n" . $CodePostal ;
$texte = $texte . " - " . $Ville ;
$texte = $texte . "\nPays : " . $Pays ;
$texte = $texte . "\n\nT�l�phone : " . $Tel ;
$texte = $texte . "\nE-mail : " . $Email ;

$texte = $texte . "\n\nDemande effectu�e le : " . date("d/m/y");

print 'Inscription � la mailing list de vin-et-champagne.com<br><br>Votre demande a bien �t� enregistr�e.<br>
Vous recevrez un e-mail de confirmation d\'inscription.<br>
Merci de votre int�r�t.</p></div>';

mail ("mailinglist@vin-et-champagne.com", "vin-et-champagne.com : inscription � la mailing-list", $texte)

?>
</body>
</html>

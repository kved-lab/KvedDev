<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_05.gif" alt="" border="0"></td>
</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		<td valign="top">
		<p><img src="images/invisible.gif" width="400" height="1" alt="" border="0"><br>
<?
include("bib_functions.php");
$id=id_session($session);
$paiement=paiement_session($session);
$modpass=modpass_session($session);
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
$query2="SELECT * FROM client WHERE id='$id' AND modpass='$modpass'";
$res2 = mysql_query($query2,$db);
if (mysql_num_rows($res2)==1) {
	$row2 = mysql_fetch_row($res2);
	echo "Compte: $id <br><br>";
	// Affiche propri�t� client
	$nomfact=$row2[1];
	$prenomfact=$row2[0];
	$adrfact=$row2[4];
	$villefact=$row2[6];
	$cpfact=$row2[7];
	$telfact=$row2[5];
	$adrliv=$row2[8];
	$villeliv=$row2[10];
	$cpliv=$row2[11];
	$telliv=$row2[9];
	$societefact=$row2[13];
	$prenomliv=$row2[14];
	$nomliv=$row2[15];
	$societeliv=$row2[16];
	$paysfact=$row2[17];
	$paysliv=$row2[18];
	$emailliv=$row2[19];
	$emailfact=$row2[20];
	echo "<b>Votre compte:</b><BR><BR>";	
	echo "- <u>Adresse de facturation: </u>";
	echo "<blockquote>$nomfact $prenomfact<br>";
	echo "E-mail: ".$emailfact;
	if (!empty($societe)) {echo " de la societ� $societefact<br>";} else {echo "<br>";}
	echo "$adrfact <br>$cpfact $villefact <br>$paysfact<br> Tel: $telfact </blockquote>";
	if (!empty($adrliv)&&!empty($villeliv)) {
		echo "- <u>Adresse de livraison: </u><br>";
		echo "<blockquote>$nomliv $prenomliv <br>";
		echo "E-mail: ".$emailliv; 
		if (!empty($societe)) {echo " de la societ� $societeliv";}
		echo "<br>$adrliv <br>$cpliv $villeliv <br>$paysliv<br> Tel: $telliv<br></blockquote>";
	}
	// Affiche commande
	$query_com="SELECT * FROM panier WHERE idsession='$session'";
	$res1 = mysql_query($query_com,$db);
	echo "<br><b>Votre Commande:</b><br>";
	$montant=0;
	while ($row1=mysql_fetch_row($res1)) {	
		$nuart=$row1[3];
		$qte=$row1[4];
		$sub_query="SELECT libelle_article,prix from article WHERE code_article='$nuart'";
		$res2 = mysql_query($sub_query,$db);
		$row2=mysql_fetch_row($res2);
		if (mysql_num_rows($res1)!=0) {
			echo "<i>$qte $row2[0]</i><br>";
			$montant=$montant+$row2[1]*$qte;
		}
	}
	if ($montant==0) {echo "Votre panier est vide";} 
	else {
	echo "<br>Total: ".$montant." Euros";
	if ($paiement=="cheque") {$paiement="Ch�que";}
	if ($paiement=="cb") {$paiement="CB";}
	echo "<br>Paiement: $paiement";
	?>
<br>
<form name="form1" method="post" action="valid_commande.php">
	<input type="hidden" name="session" value="<?echo $session; ?>">
	<input type="hidden" name="montant" value="<?echo $montant; ?>">
	<input type="submit" name="valide" value="Validation" class="form">
</form>
<form name="form2" method="post" action="modif_client.php?session=<?echo $session; ?>">
	<input type="hidden" name="session" value="<?echo $session; ?>">
	<input type="submit" name="Modif" value="Modifier votre compte" class="form">
</form>	
<?	
}
} else {echo "Client inconnu";}
?>
</td></tr></table></td></tr></table>
<body>
</html>
<?
echo ("<html>
<head>
<title>information client</title>
<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
</head><body leftmargin=5 topmargin=0 marginheight=\"0\" marginwidth=\"5\" bgcolor=\"#C0BCBB\" background=\"images/f_body.gif\" style=\"background-repeat:no-repeat;\" bgproperties=\"FIXED\">
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
<tr>
	<td colspan=\"2\"><img src=\"images/titre/ts_05.gif\" border=\"0\"></td>
</tr>
<tr>
	<td background=\"images/f_cell_b_g.gif\" valign=\"top\"><img src=\"images/invisible.gif\" width=\"5\" height=\"150\" border=\"0\"></td>
	<td valign=\"top\">
	<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
		<tr>
		<td valign=\"top\">
		<p><img src=\"images/invisible.gif\" width=400 height=1><br>");
echo "Bienvenue ! Votre identifiant est $id<br>";
echo("Votre compte a bien �t� enregistr�.<br><br><input type=\"submit\" name=\"Submit\" value=\"Retour\" onclick='history.go(-2)' class=\"form\">");
echo ("</td></tr></table></td></tr></table></BODY>");

?>
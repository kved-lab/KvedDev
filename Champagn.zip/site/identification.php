<?
/*
<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">


<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_05.gif" alt="" border="0"></td>
</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		<td valign="top">
		<p><img src="images/invisible.gif" width="400" height="1" alt="" border="0"><br>
*/
?>
<?
include("bib_functions.php");

$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
$query="Select * from client where id='$id0' AND modpass='$modpass'";
$res = mysql_query($query,$db);

mysql_close($db);

if (mysql_num_rows($res)) {
	if (signe_session($session,$id0,$modpass)) {
		header("Location:confirm_commande.php?session=$session");	
	} else {
		echo "<body leftmargin=\"5\" topmargin=\"0\" marginheight=\"0\" marginwidth=\"5\" bgcolor=\"#C0BCBB\" background=\"images/f_body.gif\" style=\"background-repeat:no-repeat;\" bgproperties=\"FIXED\">";
		echo "Session inconnue";
		echo "<body>";
		}
} else {echo("Erreur de login ou de mot de passe<br><br><input type=\"submit\" name=\"Submit\" value=\"Retour\" onclick='history.go(-1)' class=\"form\">");}

?>
<?/*
</td>
		</tr>
	</table>
	</td>
</tr>
</table>
</body>
</html>
*/?>
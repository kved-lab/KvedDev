//ChangeText object constructor.
function makeChangeTextObj(obj){
   	this.css = bw.dom?document.getElementById(obj).style:bw.ie4?document.all[obj].style:bw.ns4?document.layers[obj]:0;	
   	this.writeref = bw.dom?document.getElementById(obj):bw.ie4?document.all[obj]:bw.ns4?document.layers[obj].document:0;	
	this.writeIt = b_writeIt;					
}
function b_writeIt(text,num){
	if (bw.ns4){
		this.writeref.write(text)
		this.writeref.close()
	}
    else this.writeref.innerHTML = messages[num]
}

//The mouoseover function. Calls the writeIt method to write the text to the div.
function changeText(num){
	if(bw.bw) oMessage.writeIt('<table width="'+msgWidth+'" border="0" cellpadding="0" cellspacing="0"><tr><td><span style="font-size:'+msgFontSize+'px; font-family:'+msgFont+'; color:'+msgFontColor+'">'+messages[num]+'</span></td></tr></table>', num)
}

//The init function. Calls the object constructor and initiates some properties.
function changeTextInit(){
	//Fixing the browsercheck for opera... this can be removed if the browsercheck has been updated!!
	bw.opera5 = (navigator.userAgent.indexOf("Opera")>-1 && document.getElementById)?true:false
	if (bw.opera5) bw.ns6 = 0
	
	oMessage = new makeChangeTextObj('divMessage')
	oLinks = new makeChangeTextObj('divLinks')
	//Setting the style properties of the text layer.
	if(bw.dom || bw.ie4){
		with(oMessage.writeref.style){fontFamily=msgFont; fontSize=msgFontSize+"px"; color=msgFontColor}
	}
	//Both layers are hidden by default to prevent users from mousing over them and creating errors while the page loads.
	oMessage.css.visibility= "visible"
	oLinks.css.visibility= "visible"
}

//If the browser is ok, the init function is called on pageload. 
if (bw.bw) onload = changeTextInit
<?

function signe_session($session,$id,$modpass) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);	
	// Mise � jour session avec id et modpass
	$update_sess = "UPDATE session SET id='$id', modpass='$modpass' WHERE session='$session'";
	$res1=mysql_query($update_sess,$db);
	if ($res1) {$ret=1;} else {$ret=0;}
	mysql_close($db);
	return($ret);
}

function mode_paiement($cheque,$session) {
	//Renseigne le mode de paiement dans table session
	if (empty($cheque)) {$paiement="cb";} else {$paiement="cheque";} 
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query = "UPDATE session SET paiement='$paiement' WHERE session='$session'";
	$res1=mysql_query($query,$db);
	if (!$res1) { echo "Session inconnue";$ret=0;} else {$ret=1;}
	mysql_close($db);
	return($ret);
}

function id_session($session) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query1="SELECT id FROM session WHERE session='$session'";
	$res1 = mysql_query($query1,$db);
	if ($row1 = mysql_fetch_row($res1)) {$id=$row1[0];}
	mysql_close($db);
	return($id);
}
function paiement_session($session) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query1="SELECT paiement FROM session WHERE session='$session'";
	$res1 = mysql_query($query1,$db);
	if ($row1 = mysql_fetch_row($res1)) {$paiement=$row1[0];}
	mysql_close($db);
	return($paiement);
}
function modpass_session($session) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query1="SELECT modpass FROM session WHERE session='$session'";
	$res1 = mysql_query($query1,$db);
	if ($row1 = mysql_fetch_row($res1)) {$modpass=$row1[0];}
	mysql_close($db);
	return($modpass);
}

function ajout_histo($session,$cat1, $cat2, $cat3) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query1="insert INTO histo (session,cat1,cat2,cat3) VALUES('$session','$cat1','$cat2','$cat3')";
	$res1 = mysql_query($query1,$db);
	if ($res1==1) {return 1;} else {return 0;}
	mysql_close($db);
}

function fraisDePort($cp, $pays) {
if ($pays=="fr") {
	$dpt=substr($cp,0,2);
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query="SELECT fraisport.fraisport FROM defzone,fraisport WHERE defzone.pays='$pays' AND defzone.dpt='$dpt' AND defzone.zone=fraisport.zone";
	$res=mysql_query($query,$db);
	if (mysql_num_rows($res)==1) {
		$row=mysql_fetch_row($res);
		$frais=$row[0];
		} else $frais="Non d�fini";
	return $frais;
	mysql_close($db);
}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<? if (($pass=="admin1")&&($idadmin=="admin1")) { ?>
<html>
<head>
	<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<script language="javascript">
function mab() {
parent.middleFrame.location.href='maintenance_alert.htm';
}
</script>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB">
<div align="center">
<form name="form1" method="post" action="Maintenance_SQL.php" target=middleFrame>
  
<table border="0" cellspacing="0" cellpadding="6">
	<tr>
		<td><p>Cat&eacute;gorie 1* :<br>
		<select name="categorie1" class="form">
		<option value="-"  >-</option>
          <?
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	$query="";
	$query ="select distinct cat1 from categories ";
	$res = mysql_query($query,$db);
	while ($row=mysql_fetch_row($res)) {
	$cat=$row[0];
	echo ("<option value=\"".$cat."\">".$cat."</option>)");
	}
	
	?>
		</select></p>
		</td>

		<td><p>Cat&eacute;gorie2 *:<br>
		<select name="categorie2" class="form">
		<option value="-"  >-</option>
          <?
	$query=" ";
	$query ="select distinct cat2 from categories where cat2<>'-'";
	$res2 = mysql_query($query,$db);
	while ($row2=mysql_fetch_row($res2)) {
	$cat=$row2[0];
	echo ("<option value=\"".$cat."\">".$cat."</option>)");
	}
	?>
		</select></p>
		</td>

		<td><p>Cat&eacute;gorie 3 :<br>
		<select name="categorie3" class="form">
		<option value="-"  >-</option>
          <?
	$query=" ";
	$query ="select distinct cat3 from categories where cat3<>'-'";
	$res3 = mysql_query($query,$db);
	while ($row3=mysql_fetch_row($res3)) {
		$cat=$row3[0];
		echo ("<option value=\"".$cat."\">".$cat."</option>)");
	}
	mysql_close($db);
	?>
        </select></p>
		</td>
	</tr>

	<tr>
		<td colspan="2"><p>Article :<br>
		<input type="text" name="libelle" class="form" size="25" style="width: 200px"></p></td>
		<td><p>Appelation :<br>
		<input type="text" name="cru" class="form" size="17" style="width: 150px"></p></td>
	</tr>
	<tr>
		<td class="right" colspan="2"><p>Prix unitaire &agrave; la vente en euro :</p></td>
		<td nowrap><input type="text" name="prix" class="form" size="4" style="width: 50px"></td>
	</tr>

	<!-- <tr>
		<td><p>Descriptif :</p></td>
		<td colspan="2"><textarea name="descriptif" default value="a "></textarea></td>
	</tr> -->
</table>
<input type="hidden" name="code" class="form">
<p><input type="submit" name="BT_insert" value="Ajouter" class="form" style="background-color:#CCCC33;">
<input type="submit" name="BT_update" value="Modifier" class="form" style="background-color:#CCCC33;">
<input type="submit" name="BT_delete" value="Supprimer" class="form" style="background-color:#CCCC33;">
<input type="reset" name="BT_delete" value="Mettre � blanc" onclick='mab()' class="form" style="background-color:#CCCC33;">

<p><input type="submit" name="Submit" value="Liste" onClick='msgwindow=window.open("maintenance_liste.php")' class="form"></p>

</form>
</div>
</body>  
</html>

<? } else echo "<body bgcolor=\"#C0BCBB\">";?>
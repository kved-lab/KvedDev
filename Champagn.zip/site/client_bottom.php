<?
if ($pseudo!='') {
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
$query="Select * from client where id='$pseudo'";
$res = mysql_query($query,$db);

if (mysql_num_rows($res)) {
	$row = mysql_fetch_row($res);
	$nomfact=$row[1];
	$prenomfact=$row[0];
	$adrfact=$row[4];
	$villefact=$row[6];
	$cpfact=$row[7];
	$telfact=$row[5];
	$adrliv=$row[8];
	$villeliv=$row[10];
	$cpliv=$row[11];
	$telliv=$row[9];
	$societefact=$row[13];
	$prenomliv=$row[14];
	$nomliv=$row[15];
	$societeliv=$row[16];
	$paysfact=$row[17];
	$paysliv=$row[18];
	$emailliv=$row[19];
	$emailfact=$row[20];
		
	echo "- <u>Adresse de facturation: </u>";
	echo "<blockquote>$nomfact $prenomfact<br>";
	echo "E-mail: ".$emailfact;
	if (!empty($societe)) {echo " de la societ� $societefact<br>";} else {echo "<br>";}
	echo "$adrfact <br>$cpfact $villefact <br>$paysfact<br> Tel: $telfact </blockquote>";
	if (!empty($adrliv)&&!empty($villeliv)) {
		echo "- <u>Adresse de livraison: </u><br>";
		echo "<blockquote>$nomliv $prenomliv <br>";
		echo "E-mail: ".$emailliv; 
		if (!empty($societe)) {echo " de la societ� $societeliv";}
		echo "<br>$adrliv <br>$cpliv $villeliv <br>$paysliv<br> Tel: $telliv<br></blockquote>";
	} else {echo "Adresse de facturation = Adresse de livraison";}
	
} else {echo "Client inconnu";}
mysql_close($db);
}
?>
<script language="javascript">
parent.body.location.href="body.htm"
</script>
<?
// A l'ouverture, envoyer l'url d'accueil dans la frame body en javascript

//   GESTION DE SESSIONS
function SessionID($length=8) {
        $sid='';
        $Pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $Pool .= "abcdefghijklmnopqrstuvwxyz";
        $lastChar = strlen($Pool) - 1;
        for($i = 0; $i < $length; $i++) {
          $sid .= $Pool[mt_rand(0, $lastChar)];
        }
        return($sid);
}

$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// Suppression des anciennes sessions
$hmoins1=time()-1800;
$supp="DELETE FROM session WHERE LastAction<".$hmoins1;
$inser_res=mysql_query($supp,$db);

// Cr�ation d'une session
$temp=time();
$session=SessionID(8);

$query="SELECT session from session where session='$session'";
$res=mysql_query($query,$db);
while (mysql_num_rows($res)) {
	$session=SessionID(8);
	$query="SELECT session from session where session='$session'";
	$res=mysql_query($query,$db);
}

// Ecriture de la session

$inser_sess="INSERT INTO session (session,Last_action)VALUES('$session','$temp')";
$inser_res=mysql_query($inser_sess,$db);

// Ecriture de la visite

$ip=$REMOTE_ADDR;
$today = date("d-m-Y");
$hour = date("H:i:s");
$inser_visite="INSERT INTO visites (PAGE,IP,INFO)VALUES('Champagne - Accueil','$ip','le $today � $hour')";
$inser_vis=mysql_query($inser_visite,$db);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<title>side</title>

</head>

<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#C0BCBB" background="images/invisible.gif">

<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td><a href="index.htm" target="_top"><img src="images/logo.gif" width="157" height="132" alt="" border="0"></a></td>
</tr>
<tr>
	<td>
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td valign="top"><img src="images/side/s_g.gif" width="7" height="126" alt="" border="0"></td>
			<td valign="top"><a href="bs01.htm" target="body" onmouseover="document.s_01.src='images/side/s_01_1.gif'" onmouseout="document.s_01.src='images/side/s_01_0.gif'" onfocus="this.blur();"><img src="images/side/s_01_0.gif" width="131" height="14" alt="" border="0" name="s_01"></a><br>
	<a href="bs02.htm" target="body" onmouseover="document.s_02.src='images/side/s_02_1.gif'" onmouseout="document.s_02.src='images/side/s_02_0.gif'" onfocus="this.blur();"><img src="images/side/s_02_0.gif" width="131" height="14" alt="" border="0" name="s_02"></a><br>
	<a href="bs03.htm" target="body" onmouseover="document.s_03.src='images/side/s_03_1.gif'" onmouseout="document.s_03.src='images/side/s_03_0.gif'" onfocus="this.blur();"><img src="images/side/s_03_0.gif" width="131" height="14" alt="" border="0" name="s_03"></a><br>
	<a href="bs04.htm" target="body" onmouseover="document.s_04.src='images/side/s_04_1.gif'" onmouseout="document.s_04.src='images/side/s_04_0.gif'" onfocus="this.blur();"><img src="images/side/s_04_0.gif" width="131" height="14" alt="" border="0" name="s_04"></a><br>
	<img src="images/side/s_space.gif" width="131" height="14" alt="" border="0"><br>
	<a href="visu_panier.php?session=<? echo $session; ?>" target="body" onmouseover="document.s_05.src='images/side/s_05_1.gif'" onmouseout="document.s_05.src='images/side/s_05_0.gif'" onfocus="this.blur();"><img src="images/side/s_05_0.gif" width="131" height="14" alt="" border="0" name="s_05"></a><br>
	<a href="bs06.htm" target="body" onmouseover="document.s_06.src='images/side/s_06_1.gif'" onmouseout="document.s_06.src='images/side/s_06_0.gif'" onfocus="this.blur();"><img src="images/side/s_06_0.gif" width="131" height="14" alt="" border="0" name="s_06"></a><br>
	<img src="images/side/s_space.gif" width="131" height="14" alt="" border="0"><br>
	<a href="bs07.htm" target="body" onmouseover="document.s_07.src='images/side/s_07_1.gif'" onmouseout="document.s_07.src='images/side/s_07_0.gif'" onfocus="this.blur();"><img src="images/side/s_07_0.gif" width="131" height="14" alt="" border="0" name="s_07"></a></td>
			<td valign="top"><img src="images/side/s_d.gif" width="12" height="126" alt="" border="0"></td>
</tr>
<tr>
	<td colspan="3"><a href="bs08.htm" target="body" onmouseover="document.s_08.src='images/side/s_08_1.gif'" onmouseout="document.s_08.src='images/side/s_08_0.gif'" onfocus="this.blur();"><img src="images/side/s_08_0.gif" width="150" height="20" alt="" border="0" name="s_08"></a></td>
</tr>
	</table>
	</td>
</tr>
</table>

<div id="bloc_recherche" style="position:absolute; z-index:1; left: 2px; top: 280px;">
<img src="images/bloc_recherche.gif" width="140" height="75" alt="" border="0">
</div>

<div id="recherche" style="position:absolute; z-index:2; left: 11px; top: 303px;">
<table border="0" cellspacing="0" cellpadding="2">
<form name="monform" action="recherche.php" target="body">
<input type="hidden" name="session" value="<?echo $session;?>" >
<tr>
	<td><input type="text" name="rech" size="14" style="font: 9px verdana, Arial, Helvetica; background-color: #ffffff; border: 1 solid black; width: 117px;"></td>
</tr>
<tr>
	<td><img src="images/invisible.gif" width="42" height="5" alt="" border="0">
	<input type="image" src="images/bt_rech_0.gif" width="38" height="13" alt="" border="0" 
	  name="bt_rech" 
	  onFocus="this.blur();" 
	  onmouseover="this.src='images/bt_rech_1.gif'" 
	  onmouseout="this.src='images/bt_rech_0.gif'">
	</td>
</tr></form>
</table>

</div>

<div id="compte" style="position:absolute; z-index:1; left: 3px; top: 362px;">
<img src="images/side/s_compte.gif" width="138" height="57" border="0" usemap="#compte">
</div>


<map name="compte">
<area alt="" coords="8,19,128,31" href="visu_panier.php?session=<? echo $session; ?>" target="body" onfocus="this.blur();">
<area alt="" coords="8,37,128,50" href="form_inscription.php" target="body" onfocus="this.blur();">
</map>	


</body>
</html>

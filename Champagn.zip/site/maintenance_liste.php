<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<?
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
$query ="select * from article where libelle_article<>'' order by categorie1, categorie2, categorie3, libelle_article";
$res = mysql_query($query,$db);
Print ("Liste des articles: ");
echo "<CENTER>";
echo "<TABLE BORDER=0 CELLSPACING=10 width=100%>";
echo "<H1><TR><TD> <b>Cat�gorie 1</b></TD><TD><b> Cat�gorie 2</b></TD><TD><b> Cat�gorie 3</b></TD><TD> <b>Nom </b></TD><TD><b> Prix </b></TD>
<TD><b> Date d'entr�e </b></TD></H1><tr>";
// liste des articles
$cact01="";
$cact02="";
$cact03="";
while ($row=mysql_fetch_row($res)) {
	if ($cat01==$row[2]) {$cat1="";} else {$cat1=$row[2];$cat01=$row[2];}
	if ($cat02==$row[3]) {$cat2="";} else {$cat2=$row[3];$cat02=$row[3];}
	if ($cat03==$row[4]) {$cat3="";} else {$cat3=$row[4];$cat03=$row[4];}
	$nom=$row[1];
	$prix=$row[5];
	$date=$row[7];
	echo "<TR>";
	echo "<TD>";
	echo "$cat1"; echo "</TD>";
	echo "<TD>";
	echo "$cat2"; echo "</TD>";
	echo "<TD>";
	echo "$cat3"; echo "</TD>";
	echo "<TD>";
	echo "$nom"; echo "</TD>"; 
	echo "<TD>";
	echo "$prix"; echo "</TD>";
	echo "<TD>";
	echo "$date"; echo "</TD>";
}
mysql_close($db);
?>

</body>
</html>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">


<?if (($pass=="admin1")&&($idadmin=="admin1")) { ?>

<html>
<head>
	<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">
<form name="form1" method="post" action="Maintenance_SQL.php" target=middleFrame>
<table border="0" cellspacing="0" cellpadding="4">
<tr>

<br><b> Bonjour <? echo $idadmin ;?>, <br>Bienvenue la page de maintenance du site:<br>
<br>
<td align="left" >
<a target="_blank" href="maintenance_cat_frame.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>">- Modification des sous-cat�gories</a>
<br>
<a target="_blank" href="affiche_commande.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>">- Affichage des commandes re�ues</a>
<br>
<a target="_blank" href="Maintenance_images.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>">- Mise � jour des modules</a>
<br>
<a href="http://www.vin-et-champagne.com" target="_blank" onfocus="this.blur();">- http://www.vin-et-champagne.com</a>
</tr>
<br>
<tr>
	<td class="right"><table border="0" cellspacing="0" cellpadding="4">
	<tr>
		<td><p class="right">- <b>Modifier</b> un article: </p></td>
		<td><select name="code" size="1" length=50 onChange='parent.topFrame.form1.BT_select.click()' class="form">
      		<option value="">liste article </option>
		<?
		$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
		mysql_select_db("frederic.bertrand2",$db);
		$query ="select code_article, libelle_article, cru from article order by libelle_article ";
		$res = mysql_query($query,$db);
		while ($row=mysql_fetch_row($res)) 
                	{
			$code=$row[0];
			$cru=$row[2];
			$libelle=$row[1];
			echo ("<option value=\"".$code."\">".$libelle." ".$cru."</option>");
			}
		mysql_close($db);
		?>
		
		</select></td>
		<td><input type="submit" name="BT_select" value="Rechercher" class="form" style="background-color:#CCCC33;"></td>
	</tr>
	</table>
	</td>
</tr>
</table>
</form>


</body>
</html>
<?} else {echo "<body bgcolor=\"#C0BCBB\"><script language=\"javascript\"> document.write('Vous n etes pas autoris� � modifier la base article');</SCRIPT></body>";}?>

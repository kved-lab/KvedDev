<?
include("bib_functions.php");
function entete ($err) {
  if ($err==0) {
    echo ("<html>
	<head>
	<title>information client</title>
	<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">
	</head>");
	    echo ("<body leftmargin=5 topmargin=0 marginheight=\"0\" marginwidth=\"5\" bgcolor=\"#C0BCBB\" background=\"images/f_body.gif\" style=\"background-repeat:no-repeat;\" bgproperties=\"FIXED\">
	<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	<tr>	
	
	<!--   MATHIEU: ICI IMAGE AVEC TEXTE ERREUR ou MESSAGE -->
	
	<td colspan=\"2\"><img src=\"images/titre/ts_05.gif\" border=\"0\"></td>
	</tr>
	<tr>
	<td background=\"images/f_cell_b_g.gif\" valign=\"top\"><img src=\"images/invisible.gif\" width=\"5\" height=\"150\" border=\"0\"></td>
	<td valign=\"top\">
	<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
	<tr>
	<td valign=\"top\">
	<p><img src=\"images/invisible.gif\" width=400 height=1><br>
	Formulaire invalide ou incomplet, veuilez corriger les erreurs suivantes:<br><br>
	");
  }
}
$mailfact=$id0;
$id0=strtok($mailfact,"@");
$erreur=0;
if (strtok("@")=="") {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- E-mail invalide</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<BR>";}
if (empty($modpass)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Mot de passe obligatoire</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<BR>";} 
else {if ($modpass!=$modpass2) {entete($erreur);$erreur=1;echo "Erreur lors de la saisie du mot de passe</a><BR>";}}
if (empty($id0)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Identifiant obligatoire</a><BR>";}
if (empty($nomfact)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Nom obligatoire</a><BR>";}
if (empty($adrfact)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Adresse obligatoire</a><BR>";}
if (empty($villefact)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Ville obligatoire</a><BR>";}
if (empty($cpfact)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Code postal  obligatoire</a><BR>";}
if (empty($paysfact)) {entete($erreur);$erreur=1;echo "<a href=javascript:history.go(-1)>- Pays obligatoire</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<BR>";} 
if ($erreur==0) {		
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);

	// V�rification unicit� du pseudo
	$query="Select id from client where id='$id0'";
	$res = mysql_query($query,$db);
	
	// Insert dans bdd base abonnes
	if (mysql_num_rows($res)==0) {
	   $inser_abo ="insert into client (prenomfact,nomfact,id,modpass,adrfact,telfact,villefact,adrliv,telliv,villeliv,cpliv,cpfact,societefact,prenomliv,nomliv,societeliv,paysfact,paysliv,emailliv,emailfact) 
                           VALUES('$prenomfact','$nomfact','$id0','$modpass','$adrfact','$telfact','$villefact','$adrliv','$telliv','$villeliv','$cpliv','$cpfact','$societefact','$prenomliv','$nomliv','$societeliv','$paysfact','$paysliv','$mailliv','$mailfact')";
	   if (mysql_query($inser_abo,$db)) {
	  
	  	if (signe_session($session,$id0,$modpass)) {
	  		header("Location:confirm_inscription.php?session=$session&id=$id0");
	  		mail($mailfact,"Votre inscription"," Votre inscription s'est d�roul�e avec succes. votre identifiant: $id0 et votre mot de passe: $modpass ","");
	  		mail("mailinglist@vin-et-champagne.com","Inscription vin-et-champagne.com"," Un nouveaux client vient de s'inscrire. Pseudo: $id0","");
			mail("vincent@vin-et-champagne.com","Inscription vin-et-champagne.com"," Un nouveaux client vient de s'inscrire. Pseudo: $id0","");
			mail("fbertrand01@mageos.com","Inscription vin-et-champagne.com"," Un nouveaux client vient de s'inscrire. Pseudo: $id0","");
	  		}
	  		
	  	// Mise � jour session avec id et modpass
	  	else {entete($erreur);$erreur=1;echo "Session inconnue";}
	   } else {entete($erreur);$erreur=1;echo "Pb d'�criture";}
  	} else {entete($erreur);$erreur=1;echo("L'ID ".$id0." est d�ja utilis� <br>\n");}
	
	mysql_close($db);
	
} else {echo ("</body>");}
	
?>

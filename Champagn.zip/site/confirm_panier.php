<?
// MATHIEU: pour rajouter du code HTML, va dans "if (!empty($caisse))", met le code entre " et ejoute un echo devant,
// un point virgule pour finir. les caract�re " doivent etre preced� d'un \

$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// CONTROLE DE LA SESSION 
$verif="SELECT session FROM session WHERE session='$session'";
$res_verif=mysql_query($verif);
if (mysql_num_rows($res_verif)!=0) {
if (!empty($delete)) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);
	for($i=0;$i<count($choix_sup);$i++) { 
		$deletpan="DELETE FROM panier WHERE num=$choix_sup[$i] and idsession='$session'";
		$res = mysql_query($deletpan,$db);
		}
	mysql_close($db);
	header ("location: visu_panier.php?session=".$session);
	}

if (!empty($caisse)) {
	echo "<body leftmargin=\"5\" topmargin=\"0\" marginheight=\"0\" marginwidth=\"5\" bgcolor=\"#C0BCBB\">";
	echo "<br><b>Montant de la facture: ".$total. " �.</b><br><br>";
	
	echo "- Par ch�que � l'adresse suivante: 12 bis rue Perrot 75012 PARIS.";
	echo "<form name=\"form1\" method=\"POST\" action=\"info_client.php\">";
	echo "<input type=\"submit\" name=\"cheque\" value=\"Valider la commande - Paiement par ch�que\"  class=\"form\" style=\"background-color:#CCCC33;\">";
	echo "<input type=\"hidden\" name=\"total\" value=\"$total\">";
	echo "<input type=\"hidden\" name=\"session\" value=\"$session\">";
	
	echo "</form><br>";

	echo "</form>";
	echo "</body>";
	} else echo ("<b>  <a href=\"javascript:history.back();\">>> retour</a></b>");
}
?>

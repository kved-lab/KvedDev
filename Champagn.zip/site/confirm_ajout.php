
 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">


<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_05.gif" alt="" border="0"></td>

</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		
		<td valign="top">
		
		<form name="form1" method="post" action="ajout_panier.php">
<?

// Ajout d'un article dans le panier
// variables d'entr�e: code article, quantit�, session$S
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// CONTROLE DE LA SESSION 

$verif="SELECT session FROM session WHERE session='$session'";
$res_verif=mysql_query($verif);
if (mysql_num_rows($res_verif)!=0) {
	echo ("<p><br><b>Vous souhaitez ajouter les articles suivant � votre panier :</b><br>
<i>Vous pouvez � tout moment ajouter ou supprimer des produits en cochant la case carr�e et en cliquant sur mise � jour en fin de liste...</i></p>");
	$tot_i=0;
	$tag=0;
	for ($i=0;$i<$nbre_choix;$i++) { 
		$prix=$prixh[$i];
		$nbre=$nbh[$i];
		$gabarit1=$gabarith[$i];
		
		/*
		echo "gab: ".$gabarit1;
		echo ", nbre: ".$nbre;
		echo ", prix: ".$prix;
		echo ", libell�: ".$libelleh[$i]."<br>";
		*/
		
		
		if (settype($prix, "double")) {
		if (settype($nbre, "integer") && settype($gabarit1, "integer")) {
			$nbre=$nbre*$gabarit1;
			if ($nbre>0) {
				$tag=1;
				$tot_i+=$prix*$nbre;
				echo ("<b>".$nbre."</b> ".$libelleh[$i]." � ".$prixh[$i]." � l'unit�s.</i><br>");// soit ".$tot_i." francs.<br>");
				echo "<input type=\"hidden\" name=\"codeh[]\" value=\"$codeh[$i]\">";
				echo "<input type=\"hidden\" name=\"qteh[]\" value=\"$nbre\">";
			}
		} else {echo ($libelle[$i].": Quantit�e inconnue");} 
		} else {echo ($libelle[$i].": prix inconnue");}
	}
	if ($tag==1) {
		echo ("<br>&nbsp;&nbsp;&nbsp;&nbsp;Soit un total de <b>".$tot_i." �</b><br clear=all><table><tr><td>Confirmez vous cet ajout ?</td><td nowrap><input type=\"hidden\" name=\"session\" value=\"$session\"><input type=\"submit\" name=\"oui\" value=\" oui\" class=\"form\" style=\"background-color:#CCCC33;\">&nbsp;&nbsp;<input type=\"submit\" name=\"non\" value=\"non\"  class=\"form\" style=\"background-color:#CCCC33;\"></td></tr></table>");
	} else {echo ("<b> Indiquez les quantit�es. <a href=\"javascript:history.back();\">>> retour</a></b>"); }
} else {echo "Erreur session";}
?>
</form>
		
		</td>
		</tr>
	</table>
	</td>
</tr>
</table>
</body>
</html>

<?
if (!empty($nomfact)) {
if (!empty($adrfact)) {
if (!empty($villefact)) {
if (!empty($cpfact)) {	
	
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

$query1="SELECT * FROM session WHERE session='$session'";
$res1 = mysql_query($query1,$db);
if ($row1 = mysql_fetch_row($res1)) {
	$id=$row1[2];
	$update_abo = "UPDATE client SET prenomfact='$prenomfact', 
					 nomfact='$nomfact', 
					 adrfact='$adrfact', 
					 telfact='$telfact', 
					 villefact='$villefact', 
					 cpfact='$cpfact', 
					 adrliv='$adrliv', 
					 telliv='$telliv', 
					 villeliv='$villeliv', 
					 cpliv=$cpliv, 
					 societefact='$societefact', 
					 prenomliv='$prenomliv', 
					 nomliv='$nomliv', 
					 societeliv='$societeliv',
					 paysfact='$paysfact',
					 paysliv='$paysliv',
					 emailliv='$mailiv',
					 emailfact='$mailfact'
					 WHERE id='$id'"; 
	echo $id." ".$update_abo;
	$res2 = mysql_query($update_abo,$db);
	if ($res2) {header("Location:confirm_commande.php?session=$session");
	} else {echo "Probl�me de mise � jour";}
} else {echo "Session non reconnue";}
mysql_close($db);
} else {echo "Code postal  obligatoire";}
} else {echo "Ville obligatoire";}
} else {echo "adresse obligatoire";}
} else {echo "Nom obligatoire";}
?>
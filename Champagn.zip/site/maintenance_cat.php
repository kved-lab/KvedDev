<?
if ($pass=="admin" && $idadmin=="admin")  {
//Fonction de g�n�ration d'ID
function SessionID($length=8) {
        $sid='';
        $Pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $Pool .= "abcdefghijklmnopqrstuvwxyz";
        $lastChar = strlen($Pool) - 1;
        for($i = 0; $i < $length; $i++) {
          $sid .= $Pool[mt_rand(0, $lastChar)];

        }
        return($sid);
}

$db = mysql_connect("localhost", "frederic.bertrand2", "zrvmgom5") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
        // Suppression des anciennes sessions
        $hmoins1=time()-1800;
        $supp="DELETE FROM session WHERE LastAction<".$hmoins1;
        $inser_res=mysql_query($supp,$db);
        // Cr�ation d'une session
        $temp=time();
        $session=SessionID(8);
        
        $query="SELECT session from session where session='$session'";
        $res=mysql_query($query,$db);
        while (mysql_num_rows($res)) {
          $session=SessionID(8);
          $query="SELECT session from session where session='$session'";
          $res=mysql_query($query,$db);
          }
        $inser_sess="INSERT INTO session (session,Last_action)VALUES('$session','$temp')";
        $inser_res=mysql_query($inser_sess,$db);

?>

<HTML>
    <HEAD>
        <TITLE>Test de menu dynamique</TITLE>
        <STYLE>
        
            .parent {
                font-family: verdana;
                font-weight: bold;
                font-size: 10pt;
                margin-top: 10;
                cursor: hand;
            }

            .child  {
                font-size: 10pt;
                font-weight: normal;
                margin-left: 14pt;
            }

            a:hover { color:red; }
        
        </STYLE>

        <SCRIPT LANGUAGE=javascript>
        
            var intCount = 0;

            //-Fonction d'ajout d'entr�es principales-------------------------
            function DynamicMenu_addParent(strName) {
                var strID = 'ID' + intCount++; 

                var strTemp = '<DIV ID="' + strID + '" CLASS="parent"';
                strTemp += ' onClick="expandCollapse(this);">';
                strTemp += '<IMG SRC="Graphics/left.gif" Height="12">';
                strTemp += '&nbsp;' + strName ;
                strTemp += '<DIV STYLE="display: none" CLASS="child"></DIV>';
                strTemp += '</DIV>';

                this.div.innerHTML += strTemp;
                this.currentChild = document.getElementById(strID);
            }

            //-Fonction d'ajout de liens dans le menu-------------------------
            function DynamicMenu_addChild(strName,strURL) {
                var strTemp = '<A HREF="' + strURL + '"'
                            + ' TARGET="mainFrame" >' 
                            + strName + '</A><BR>';

                if (document.all) {
                    this.currentChild.children[1].innerHTML += strTemp;
                } else {
                    this.currentChild.childNodes[2].innerHTML += strTemp;
                }
            }

            //-inhibe la cascade d'�v�nements au DIV conteneur----------------
            function cancelBubble(netEvent) {
                if (document.all) {
                    window.event.cancelBubble = true;
                } else {
                    netEvent.cancelBubble = true;
                }
            }

            //-Contracte ou expanse le menu-----------------------------------
            function expandCollapse(objElement) {
                if (document.all) {
                    var imgIcon = objElement.children[0];
                    objElement = objElement.children[1];
                } else {
                    var imgIcon = objElement.childNodes[0];
                    objElement = objElement.childNodes[2];
                }    

                if (objElement.style.display == "none") {  
                    objElement.style.display = "block" ;
                    imgIcon.src = "Graphics/bottom.gif" ;
                } else {
                    objElement.style.display = "none" ;
                    imgIcon.src = "Graphics/left.gif" ;
                }
            }

            //-Fonction de cr�ation de menu dynamique------------------------- 
            function DynamicMenu() {
                var id = "Menu" + intCount++;
                document.write('<DIV Id="' + id + '"></DIV>');

                this.div = document.getElementById(id);
                this.currentChild = null;

                this.addParent = DynamicMenu_addParent;
                this.addChild = DynamicMenu_addChild;
            }
       
        </SCRIPT>
    </HEAD>
    <BODY bgcolor="#C0BCBB" >
        

<p>&nbsp;</p>
<p>&nbsp;</p>
<p> 
  <SCRIPT Language="Javascript">
        
            var menu = new DynamicMenu();

            menu.addParent("Champagne");
                menu.addChild("Non millesim�s",
                              "liste_cat3.php?cat1=Champagne&cat2=non millesim�s&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Millesim�s",
                              "liste_cat3.php?cat1=Champagne&cat2=millesim�s&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Les prestiges",
                              "liste_cat3.php?cat1=Champagne&cat2=les prestiges&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Formats d'exeptions",
                              "liste_cat3.php?cat1=Champagne&cat2=formats d'exception&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                
            menu.addParent("Vins");
            	menu.addChild("Vins francais",
                              "liste_cat3.php?cat1=Vins&cat2=vins francais&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Vins du monde",
                              "liste_cat3.php?cat1=Vins&cat2=vins francais&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
            menu.addParent("Alcools");
                menu.addChild("Eaux de vie brune",
                              "liste_cat3.php?cat1=Alcools&cat2=eaux de vie brune&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Eaux de vie blanche",
                              "liste_cat3.php?cat1=Alcools&cat2=eaux de vie blanche&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Whiskies",
                              "liste_cat3.php?cat1=Alcools&cat2=whiskies&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Rhums",
                              "liste_cat3.php?cat1=Alcools&cat2=rhums&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
		menu.addChild("Vodkas",
                              "liste_cat3.php?cat1=Alcools&cat2=vodkas&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Portos",
                              "liste_cat3.php?cat1=Alcools&cat2=portos&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Divers",
                              "liste_cat3.php?cat1=Alcools&cat2=divers&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
            menu.addParent("Epicerie fine");
            	menu.addChild("Foie gras",
                              "liste_cat3.php?cat1=Epicerie fine&cat2=foie gras&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
            	menu.addChild("Truffes",
                              "liste_cat3.php?cat1=Epicerie fine&cat2=truffes&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Caviars",
                              "liste_cat3.php?cat1=Epicerie fine&cat2=caviars&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
                menu.addChild("Huiles",
                              "liste_cat3.php?cat1=Epicerie fine&cat2=huiles&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
        	menu.addChild("Vinaigres",
                              "liste_cat3.php?cat1=Epicerie fine&cat2=vinaigres&session=<?echo $session;?>&pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>");
           
        </SCRIPT>
</p>
<br>
</BODY>
</HTML>
<? } else echo "?"; ?>
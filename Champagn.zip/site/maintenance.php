<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>- vin-et-champagne.com -</title>
</head>

<!-- frames -->


			<frameset rows="160,20,*" framespacing="0" frameborder="0" border="0">
		<frame src="maintenance_select.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>" name="topFrame" frameborder="No" scrolling="Auto"  marginwidth="0" marginheight="0">
		<frame src="maintenance_alert.htm" name="middleFrame" frameborder="No" scrolling="No" noresize marginwidth="0" marginheight="0">
		<frame src="maintenance_form.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>" name="bottomFrame" frameborder="No" scrolling="Auto" noresize marginwidth="0" marginheight="0">
		</frameset>



</html>

<html>
<head>
<title>Mise � jour cat�gorie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset cols="30%,*" frameborder="NO" border="0" framespacing="0"> 
  <frame name="leftFrame" scrolling="NO" noresize src="maintenance_cat.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>">
  <frame name="mainFrame" src="liste_cat3.php?pass=<?echo $pass;?>&idadmin=<?echo $idadmin;?>">
</frameset>
<noframes><body bgcolor="#FFFFFF" text="#000000">

</body></noframes>
</html>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">


<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_rech.gif" alt="" border="0"></td>

</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		
		<td valign="top">
		<p class="right"><br><b>Choisissez la quantit� d'un ou plusieurs articles,<br>
		et son conditionnement <i style="color:red;">(l�gende : bt = bouteille; cs=caisse)</i>.<br>
		Pour les ajouter � votre panier, cliquez sur n'importe quel caddie. :</b><br>
<i>Vous pourrez � tout moment ajouter ou supprimer des produits en consultant votre panier.</i></p>
		<form name="form1" method="post" action="confirm_ajout.php">
<?
echo "<p class=\"center\"><b>Vous avez recherch� :</b> ".$rech."<br>&nbsp;</p>";
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// Ecriture de la visite
$ip=$REMOTE_ADDR;
$today = date("d-m-Y");
$hour = date("H:i:s");
$inser_visite="INSERT INTO visites (PAGE,PARAM,IP,INFO)VALUES('Recherche','$rech','$ip','le $today � $hour')";
$inser_vis=mysql_query($inser_visite,$db);

// recherche dans libelle article
$query ="select * from article where libelle_article LIKE '%$rech%' ORDER BY categorie1, categorie2";
$res = mysql_query($query,$db);
//if mysql_length($res) {echo ("Recherche  dans libell� des articles");}
$cat1="";
$nbre_choix=mysql_num_rows($res);
echo "<input type=\"hidden\" name=\"nbre_choix\" value=\"$nbre_choix\">";
$i=0;
if ($nbre_choix==0) {echo "Aucun r�sultat por cette recherche";}
if ($nbre_choix<50) {
while ($row=mysql_fetch_row($res)) {
	$i++;
	$code=$row[0];
	$libelle=$row[1];
	$prix=$row[5];
	$cru=$row[8];
	//$descriptif=$row[6];
	?>
	<script language="JavaScript">
	  idsession=parent.side.document.monform.session.value;
	   document.write('<input type=hidden name=session value='+idsession+'>');
	</script>
	<?
	echo "<input type=\"hidden\" name=\"codeh[]\" value=\"$code\">";
	echo "<input type=\"hidden\" name=\"libelleh[]\" value=\"$libelle\">";
	echo "<input type=\"hidden\" name=\"prixh[]\" value=\"$prix\">";
	//echo "<input type=\"hidden\" name=\"descriptifh[]\" value=\"$descriptif\">";
	
        if ($cat1!=$row[2]) {
            if ($i>1)  echo "</table>";
            if ($row[2]!="-") echo ("<br><b style=\"font-size:13;\"><i>".$row[2]."</i></b><hr align=\"left\" width=\"100%\" size=\"1\">");
              $cat1=$row[2];
	      echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" width=\"100%\">";
	    }
	    if ($cat2!=$row[3]) {	
	      if ($row[3]!="-") echo ("<tr><td colspan=\"8\"><b style=\"font-size:13;\"><i>".$row[3]."</i></b><td></tr>");
              $cat2=$row[3];
            }
        ?>
	<tr>
		<td width="8"><img src="images/invisible.gif" width="8" height="2" alt="" border="0"></td>
		<td valign="top" width="220"><li type="square"><b><?echo $libelle?></b></td>
		<td valign="top" width="150"><i><?echo $cru?></i></td>
		<td nowrap valign="top" width="36">&nbsp;&nbsp;-----&nbsp;&nbsp;</td>
		<td valign="top" nowrap width="64"><?echo $prix?> �&nbsp;&nbsp;</td>
		<td valign="top" width="42"><input type="text" name="nb[]" value="0" size="3" class="form">&nbsp;&nbsp;</td>
		<td valign="top" width="27"><img src="images/invisible.gif" width="5" height="2" alt="" border="0"><br>
<input type="image" src="images/bt_panier.gif" alt="ajouter ce produit dans votre panier" border="0" hspace="5"></td>

	</tr>

	
<?
} 
} else {echo ("  Plus de 50 articles correspondent � votre recherche. Selectionner une rubrique ci-dessus ou pr�ciser la recherche.");}
// Recherche dans nom de cat�gorie
/*
$query = "select distinct code_article, libelle_article, prix, cru 
		from article,categories
		where ((categories.cat1 ='$rech') OR (categories.cat2 ='$rech') OR (categories.cat3 ='$rech')) 
		ORDER BY article.categorie1, article.categorie2";
		//AND (categories1=cat1)  AND (categorie2=cat2) AND (categorie3=cat3) 
		
		
$res = mysql_query($query,$db);
//if mysql_length($res) {echo ("Recherche  dans libell� des articles");}
$cat1="";
$nbre_choix=mysql_num_rows($res);
echo "<input type=\"hidden\" name=\"nbre_choix\" value=\"$nbre_choix\">";
$i=0;
echo $nbre_choix;
if ($nbre_choix<50) {
while ($row=mysql_fetch_row($res)) {
	$i++;
	$code=$row[0];
	$libelle=$row[1];
	$prix=$row[2];
	$cru=$row[3];
	//$descriptif=$row[6];
	?>
	<script language="JavaScript">
	  idsession=parent.side.document.monform.session.value;
	   document.write('<input type=hidden name=session value='+idsession+'>');
	</script>
	<?
	echo "<input type=\"hidden\" name=\"codeh[]\" value=\"$code\">";
	echo "<input type=\"hidden\" name=\"libelleh[]\" value=\"$libelle\">";
	echo "<input type=\"hidden\" name=\"prixh[]\" value=\"$prix\">";
	//echo "<input type=\"hidden\" name=\"descriptifh[]\" value=\"$descriptif\">";
	
        if ($cat1!=$row[2]) {
            if ($i>1)  echo "</table>";
            if ($row[2]!="-") echo ("<br><b style=\"font-size:13;\"><i>".$row[2]."</i></b><hr align=\"left\" width=\"100%\" size=\"1\">");
              $cat1=$row[2];
	      echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" width=\"100%\">";
	    }
	    if ($cat2!=$row[3]) {	
	      if ($row[3]!="-") echo ("<tr><td colspan=\"8\"><b style=\"font-size:13;\"><i>".$row[3]."</i></b><td></tr>");
              $cat2=$row[3];
            }
        ?>
	<tr>
		<td width="8"><img src="images/invisible.gif" width="8" height="2" alt="" border="0"></td>
		<td valign="top" width="220"><li type="square"><b><?echo $libelle?></b></td>
		<td valign="top" width="150"><i><?echo $cru?></i></td>
		<td nowrap valign="top" width="36">&nbsp;&nbsp;-----&nbsp;&nbsp;</td>
		<td valign="top" nowrap width="64"><?echo $prix?> �&nbsp;&nbsp;</td>
		<td valign="top" width="42"><input type="text" name="nb[]" value="0" size="3" class="form">&nbsp;&nbsp;</td>
		<td valign="top" width="27"><img src="images/invisible.gif" width="5" height="2" alt="" border="0"><br>
<input type="image" src="images/bt_panier.gif" alt="ajouter ce produit dans votre panier" border="0" hspace="5"></td>

	</tr>

	
<?
} 
} else {echo ("  Plus de 50 articles correspondent � votre recherche. Selectionner une rubrique ci-dessus ou pr�ciser la recherche.");}
*/



mysql_close($db);
?>
</form>
</table>
		
		</td>
		</tr>
	</table>
	</td>
</tr>
</table>
</body>
</html>

<? 
/*
$cat1=stripslashes($cat1);
$cat2=stripslashes($cat2);
$cat3=stripslashes($cat3);*/

include("bib_functions.php");
ajout_histo($session,$cat1,$cat2,$cat3);
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// Ecriture de la visite

$ip=$REMOTE_ADDR;
$today = date("d-m-Y");
$hour = date("H:i:s");
$inser_visite="INSERT INTO visites (PAGE,PARAM,IP,INFO)VALUES('Selection','$cat2','$ip','le $today � $hour')";
$inser_vis=mysql_query($inser_visite,$db);

// AFFICHAGE DESCRIPTIF CATEGORIE2
$query="select cat1,cat3 from categories where cat2='$cat2'";
$res = mysql_query($query,$db);
$row=mysql_fetch_row($res);
$cat1=$row[0];
$cat3=$row[1];
if ($cat1=="Epicerie fine") $cat1="Epicerie";
ajout_histo($session,$cat1,$cat2,$cat3);
?>

 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">


<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/<? echo $cat1; ?>.gif" width="237" height="19" alt="" border="0"></td>

</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		
		<td valign="top">
		<p class="right"><br><b>Choisissez la quantit� d'un ou plusieurs articles,<br>
		et son conditionnement <i style="color:red;">(l�gende : bt = bouteille; cs=caisse)</i>.<br>
		Pour les ajouter � votre panier, cliquez sur n'importe quel caddie. :</b><br>
<i>Vous pourrez � tout moment ajouter ou supprimer des produits en consultant votre panier.</i><br>&nbsp;</p>
<?
$query ="select * from article where categorie2='$cat2'";
$query=$query." order by categorie1,categorie2,categorie3,libelle_article";
$res = mysql_query($query,$db);
$cat3="gloubiboulga";

//Mettre $cat2bis= MAJUSCULE($cat)
echo "<b style=\"font-size:13;\"><i>".stripslashes($cat2)."</i></b>";
if ($nbre_choix=mysql_num_rows($res)) {
?>
<form name="form1" method="post" action="confirm_ajout.php">

<?

echo "<input type=\"hidden\" name=\"nbre_choix\" value=\"$nbre_choix\">";
$i=0;
while ($row=mysql_fetch_row($res)) {
	$i++;
	$code=$row[0];
	$libelle=$row[1];
	$cat1=$row[2];
	$prix=$row[5];
	$cru=$row[8];
	//$descriptif=$row[6];
	?>
	<script language="JavaScript">
	  idsession=parent.side.document.monform.session.value;
	   document.write('<input type=hidden name=session value='+idsession+'>');
	</script>
	
	<input type="hidden" name="codeh[]" value="<?echo $code?>">
	<input type="hidden" name="libelleh[]" value="<?echo $libelle?> ">
	<input type="hidden" name="prixh[]" value="<?echo $prix?>">
	<?
	//echo "<input type=\"hidden\" name=\"descriptifh[]\" value=\"$descriptif\">";
        if ($cat3!=$row[4]) {
            if ($i>1)  echo "</table></blockquote>";
            if ($row[4]!="-") echo ("<p><b><i>".$row[4]."</i></b></p>");
            $cat3=$row[4];
              $fic=stripSlashes($cat3).".txt";
              if(file_exists($fic)){?>
            <table width="90%" border="1" cellspacing="0" cellpadding="4" align="center" bordercolor="#CFE020" bordercolorlight="#E1F322" bordercolordark="#8E9915">
              <tr> 
                <td>
                  <p><b>
                  	<?
                  	$myfile = fopen($fic, "r");
 			while(!feof($myfile)){
 		          $myline=fgets($myfile,255);
  			  echo ($myline." <br>\n");
  			}
 			fclose($myfile); 
 			?>
			</b></p>
                </td>
              </tr>
            </table>
            <? } ?>
            <!--<p><b>:: Cat�gorie 4 ::</b></p>-->

	<table border="0" cellspacing="0" cellpadding="2" width="100%">
	<? } ?>
	<tr>
		<td width="8"><img src="images/invisible.gif" width="8" height="2" alt="" border="0"></td>
		<td valign="top" width="220"><li type="square"><b><?echo $libelle?></b></td>
		<td valign="top" width="150"><i><?echo $cru?></i></td>
		<td nowrap valign="top" width="36">&nbsp;&nbsp;-----&nbsp;&nbsp;</td>
		<td valign="top" nowrap width="64"><?echo $prix?> �&nbsp;&nbsp;</td>
		<td valign="top" width="42">
		<input type="text" name="nbh[]" value="0" size="3" class="form">&nbsp;&nbsp;</td>
		<td valign="top" width="35">
		<select name="gabarith[]" class="form">
		<option value="1">---</option>
		<option value="1">Bt</option>
		<option value="12">Cs</option>
		</select></td>
		<td valign="top" width="27"><img src="images/invisible.gif" width="5" height="2" alt="" border="0"><br>
<input type="image" src="images/bt_panier.gif" alt="ajouter ce produit dans votre panier" border="0" hspace="5"></td>
	</tr>
<?
}
mysql_close($db);
?>
</form>
<?} else echo "<br>Aucun article disponible dans cette cat�gorie"?>
</table>
</body>
</html>

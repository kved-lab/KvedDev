<?
// Ajout d'un article dans le panier
// variables d'entr�e: code article, quantit�, session
if (($oui="oui")&&(empty($non))) {
	$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
	mysql_select_db("frederic.bertrand2",$db);

	// CONTROLE DE LA SESSION 

	$verif="SELECT session FROM session WHERE session='$session'";
	$res_verif=mysql_query($verif);
	if (mysql_num_rows($res_verif)!=0) {
		$timestamp=time();
		$heure=date("G:i",$timestamp);
		$date=date("d/m/Y",$timestamp);
		$err=0;
		for ($i=0;$i<count($codeh);$i++) { 
			$code=$codeh[$i];
			$qte=$qteh[$i];
			$inserpan ="INSERT INTO panier (qte,nuart,idsession,timestamp,heure,date) 
	        	                         VALUES($qte,$code,'$session','$timestamp','$heure','$date')";
			$res = mysql_query($inserpan,$db);
			if (!$res) {
				echo "probleme d'�criture de l'enreg";
				$err=1;
			} 
		}
		if ($err==0){
			header("Location:visu_panier.php?session=$session");
		} else {echo "probl�me d'�criture ";}
	} else {echo "Erreur Session";}
	mysql_close($db);
} else {echo ("<script language=\"javascript\"> history.go(-2)</script>");}
?>

<?
/*
Table modules
nom_module char(20),
text_module char(100),
nom_fichier_module char(20),
date_module date(0000-00-00),
*/

if (($pass=="admin")&&($idadmin=="admin")) { ?>
<html>
<body bgcolor="#C0BCBB">
<?
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
$date = date("Y-m-d");

//if (!empty($file)) copy($file,"pub.img"); 
 
$query ="UPDATE modules SET text_module='$text', nom_fichier_module='$file' WHERE nom_module='pub'";
$res1 = mysql_query($query,$db);
//if (!empty($file1)) copy($file1,"pub.img"); 
// if ($res1!=0) echo "La Mise � jour pub s'est d�roul�e avec succ�s";
$query ="UPDATE modules SET text_module='$text1', nom_fichier_module='$file1' WHERE nom_module='module1'";
$res2 = mysql_query($query,$db);
//if ($res2!=0) echo "La Mise � jour module1 s'est d�roul�e avec succ�s";
//if (!empty($file2)) copy($file1,"pub1.img"); 
 
$query ="UPDATE modules SET text_module='$text2', nom_fichier_module='$file2' WHERE nom_module='module2'";
$res3 = mysql_query($query,$db);
//if ( $res3!=0) echo "La Mise � jour module2 s'est d�roul�e avec succ�s";
if ($res1!=0 && $res2!=0 && $res3!=0) echo "Les Mises � jour s'est d�roul�e avec succ�s";

?> 
</body>
</html>
<? } else echo "<body bgcolor=\"#C0BCBB\">";?>

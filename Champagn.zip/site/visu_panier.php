
 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">


<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_05.gif" alt="" border="0"></td>

</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		
		<td valign="top">
		
		<?
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// CONTROLE DE LA SESSION 

$verif="SELECT session FROM session WHERE session='$session'";
$res_verif=mysql_query($verif);
if (mysql_num_rows($res_verif)!=0) {


$toti=0;
$query ="SELECT nuart,qte,num FROM panier WHERE idsession='$session'";
$res=mysql_query($query,$db); 

echo "<p><br><b>Vous souhaitez ajouter les articles suivant � votre panier :</b><br>
<i>Vous pouvez � tout moment ajouter ou supprimer des produits en cochant la case carr�e et en cliquant sur mise � jour en fin de liste...</i></p> ";
echo "<BR>";

?>

<form name="form1" method="post" action="confirm_panier.php">
<?
echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\">";
$nb=0;
while ($row=mysql_fetch_row($res)) {
  $nb++;
  $wnuart=$row[0];
  $wqte=$row[1];
  $wnum=$row[2];
  $selec_liart = "SELECT libelle_article,prix FROM article WHERE code_article=$wnuart";
  $res1  = mysql_query($selec_liart,$db);
  if ($row=mysql_fetch_row($res1)) {$wlibelle=$row[0];$wprix=$row[1];$wcru=$row[8];}
  $toti+=$wprix*$wqte;
  
  ?>
  <TR>
  	<td valign="top"><p><?echo $wqte?></p></td>
  	<td valign="top"><p><i>- <?echo $wlibelle?></i></p></td>
  	<td valign="top"><p><b><?echo $wcru?></b></p></td>
  	<td><p>&nbsp;&nbsp;-------&nbsp;</p></td>
  	<td valign="top"><p><?echo $wprix?> �</p></td>
  	
  	<td><input type="checkbox" name="choix_sup[]" value="<? echo $wnum; ?>" ></td></tr>

  <?
  }
  echo ("<b> Total TTC : $toti"." Euro.</b><br><br>");
  echo "<input type=\"hidden\" name=\"total\" value=\"$toti\" >";
} else echo(" Erreur Session $session");
  mysql_close($db);
echo "<input type=\"hidden\" name=\"session\" value=\"$session\">";
?>
</table>
<br>
<script language="javascript">
nb=<? echo $nb; ?>;

	if (nb!=0) {
		document.writeln("<input type=\"submit\" name=\"delete\" value=\"Mise � jour\" class=\"form\" style=\"background-color:#CCCC33;\">&nbsp;&nbsp;");		
		document.writeln("<input type=\"submit\" name=\"caisse\" value=\"Passer � la caisse\"  class=\"form\" style=\"background-color:#CCCC33;\">");
	} else {
		document.writeln("<br><b>Panier vide.</b>");
		}

</script>

</form>
		
		</td>
		</tr>
	</table>
	</td>
</tr>
</table>
</body>
</html>

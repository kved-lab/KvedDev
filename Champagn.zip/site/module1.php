<?
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
$query="SELECT text_module, nom_fichier_module FROM modules where nom_module='module1'";
$res=mysql_query($query,$db);
	
$row=mysql_fetch_row($res);
$text=$row[0];
$img=$row[1];
if (!empty($text)&&!empty($img)) {	
	?>
	<html>
	<head>
	<title>Module pub</title>
	</head>
	<body bgcolor="#C0BCBB" text="#000000">
	<? echo $text;?>
	<br><br>
	<img src="./images_modules/<? echo $img; ?>">
	</body>
	</html>
<? } else { echo "Probleme d'acc�s � la base ou module inexistant";} ?>
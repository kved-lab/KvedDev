<? if ($pass=="admin" && $idadmin=="admin")  { ?>
<html>
<body bgcolor="#C0BCBB" >
<?
if (!empty($cat2) and !empty($cat1)) {
?>
<form name="monform1" action="maintenance_ajout_cat3">
Nouvelle sous-cat�gorie: 
<input type="hidden" name="cat1" value="<?echo $cat1;?>">
<input type="hidden" name="cat2" value="<?echo $cat2;?>">
<input type="text" name="cat3">
<input type="submit" name="ajout" value="ajout">
<br>

</form>
<form name="monform2" action="maintenance_ajout_cat3">
<table>


<?
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

$query="select cat3 from categories where cat2='$cat2' and cat1='$cat1'";

$res = mysql_query($query,$db);
$cat1=stripslashes($cat1);
$cat2=stripslashes($cat2);
echo "<br><tr><td>- Les sous-rubriques de </td></tr>";
echo "<tr><td><b>".$cat1."</b></td></tr>";
echo "<tr><td><b>| ---- ".$cat2."</b></td></tr>";
$cat1=addslashes($cat1);
$cat2=addslashes($cat2);
$i=0;
while($row=mysql_fetch_row($res)) {
	$i++;
	$cat3=addslashes($row[0]);	
	$query2="select count(*) from article where categorie3='$cat3' and categorie2='$cat2' and categorie1='$cat1'";
	$cat3=stripslashes($row[0]);
	$res2=mysql_query($query2,$db);
	$row2=mysql_fetch_row($res2);
	if ($cat3=="-"){echo "<tr><td>| ---- |---- <b>Hors cat�gorie ($row2[0] articles)</b></td>";} 
		else {echo "<tr><td>| ---- |---- <b>$cat3 ($row2[0] articles)</b></td>";}
	$cat1=stripslashes($cat1);
	?>
	<td><input type="checkbox" name="cb[]" value="<? echo $cat3; ?>"> 
	<input type="hidden" name="nbart[]" value="<? echo $row2[0]; ?>">
	</td></tr>
	
	<?
	}
mysql_close($db);

?>

</table>
<input type="hidden" name="cat1" value="<? echo $cat1; ?>">
<input type="hidden" name="cat2" value="<? echo $cat2; ?>">
<input type="hidden" name="nblignes" value="<? echo $i; ?>">
<input type="submit" name="delete" value="delete">
</form>
<?
} else echo "Interface de mise � jour des sous-cat�gories";
?>
</body>
</html>
<? } else echo "Vous n'etes pas autoriser � modifier la base"; ?>
<?
//echo "$cat1 $cat2 $cat3";

//Verifier que ce nest pas le dernier cat3 de la cat2 avant de supprimer 

$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);
if (!empty($ajout)) {
	$query="INSERT INTO categories VALUES('$cat1','$cat2','$cat3')";
	$res = mysql_query($query,$db);
	if ($res==1) {
		// met a jour l'affichage de la mainframe
	} else {echo "pb d'�criture, essayez ulterieurement";}
		
} 
if (!empty($delete)) {
	for ($i=0;$i<count($cb);$i++) {
		//$cat3=addslashes($row[0]);	
		$query2="select count(*) from article where categorie3='$cb[$i]' and categorie2='$cat2' and categorie1='$cat1'";
		//$cat3=stripslashes($row[0]);
		$res2=mysql_query($query2,$db);
		$row2=mysql_fetch_row($res2);
		if ($row2[0]==0) {
			$j++;
			$query="DELETE FROM categories WHERE cat1='$cat1' and cat2='$cat2' and cat3='$cb[$i]'";
			$res = mysql_query($query,$db);
			if ($res>0) {
				// met a jour l'affichage de la mainframe
			} 
		} 
	}
	
}

mysql_close($db);
header("Location:liste_cat3.php?cat1=$cat1&cat2=$cat2&cat3=$cb[$i]");
?>
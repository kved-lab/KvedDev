
function formHandler(form){
var URL = document.form.menu.options[document.form.menu.selectedIndex].value;
parent.tv.location.href = URL;
}

// load frames //
function load4Frames(frame1,page1,frame2,page2,frame3,page3,frame4,page4) {
eval("parent."+frame1+".location='"+page1+"'");
eval("parent."+frame2+".location='"+page2+"'");
eval("parent."+frame3+".location='"+page3+"'");
eval("parent."+frame4+".location='"+page4+"'");
}

function load3Frames(frame1,page1,frame2,page2,frame3,page3) {
eval("parent."+frame1+".location='"+page1+"'");
eval("parent."+frame2+".location='"+page2+"'");
eval("parent."+frame3+".location='"+page3+"'");
}

function load2Frames(frame1,page1,frame2,page2) {
eval("parent."+frame1+".location='"+page1+"'");
eval("parent."+frame2+".location='"+page2+"'");
}

function load1Frames(frame1,page1) {
eval("parent."+frame1+".location='"+page1+"'");
}
// End //



// centered popup

function NewWindow(mypage, myname, w, h, scroll) {
var winl = (screen.width - w) / 2;
var wint = (screen.height - h) / 2;
winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
win = window.open(mypage, myname, winprops)
if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}
//  End -->



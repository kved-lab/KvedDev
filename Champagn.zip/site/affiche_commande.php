
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">
<?
echo "<center><h2>Les commandes recues</center></h2>";
//echo "<br><a href=\"#\">Effacer le carnet de commande</a><br><br>";
$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

$query="SELECT * FROM et_commande ORDER BY numcom";
$res=mysql_query($query,$db);
while ($row=mysql_fetch_row($res)) {
	$numcom=$row[0];
	$date=$row[1];
	$heure=$row[2];
	$id=$row[3];
	$montant=$row[6];
	$paiement=$row[8];
	
	echo "Commande N�: ".$numcom;
  	echo " le ".$date;
  	echo " � ".$heure;
  	echo " pour ".$id;
  	echo "<br>";
  	echo "Montant: ".$montant." Euros.";
  	echo "Paiement par ".$paiement;
  	echo " pour ".$id;
  	echo "<br>";
  	$query1 ="SELECT * FROM dt_commande WHERE numcom='$numcom'";
  	$res1 = mysql_query($query1,$db);
  	echo "<blockquote>";
	while ($row1=mysql_fetch_row($res1)) {
		$numart=$row1[2];
		$qte=$row1[3];
		$query2 ="SELECT libelle_article,cru FROM article WHERE code_article='$numart'";
  		$res2 = mysql_query($query2,$db);
		$row2=mysql_fetch_row($res2);
		echo "- ".$qte." ".$row2[0]." ".$row2[1]."<br>";
	}
  	echo "----------------------------</blockquote>";
}
?>
</BODY>
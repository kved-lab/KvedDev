<html>
<title>Alert Maintenance</title>
<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0"  bgcolor="#C0BCBB" style="background-repeat:no-repeat;">
<?
// Variables d'entr�e:
//  $BT_update, $BT_select, $BT_insert ou $BT_delete
//  $article, $cat�gorie, $prix, $descriptif
if (empty($categorie3)) {$categorie3="-";}

$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);

// recherche Articles
if (!empty($BT_select)) {
	if (!empty($code)) {
		$query ="select * from article WHERE code_article=$code";
		$res = mysql_query($query,$db);
		$row=mysql_fetch_row($res);

		// Mise � jour affichage
		$libelle=$row[1];
		$cru=$row[8];
		$cat1=$row[2];
		$cat2=$row[3];
		$cat3=$row[4];
		$prix=$row[5];
		//$descriptif=$row[6];
		//echo $cat1.$cat2.$cat3;
		echo ("<SCRIPT language=\"javascript\">");
		echo ("parent.bottomFrame.form1.libelle.value='".$libelle."';");
		echo ("parent.bottomFrame.form1.cru.value='".$cru."';");
		echo ("parent.bottomFrame.form1.categorie1.value='".addslashes($cat1)."';");
		echo ("parent.bottomFrame.form1.categorie2.value='".addslashes($cat2)."';");
		echo ("parent.bottomFrame.form1.categorie3.value='".addslashes($cat3)."';");
		echo ("parent.bottomFrame.form1.prix.value='".$prix."';");
		//echo ("parent.bottomFrame.form1.descriptif.value='".$descriptif."';");
		echo ("parent.bottomFrame.form1.code.value='".$code."';");
		echo ("</SCRIPT>");
		echo ("<table width=\"100%\" border=\"0\"><tr><td>Article: ".$libelle."</td><td>"); 
		echo ("</td></tr></table>");
			
		}
	}

if (!empty($BT_update)) 
	{
	echo $categorie1." ".$categorie2." ".$categorie3;
	$query ="SELECT * from categories where cat1='$categorie1' and cat2='$categorie2' and cat3='$categorie3'";
	$res=mysql_query($query,$db);
        if (mysql_num_rows($res)==0) {echo ("Cat�gories incoh�rentes   ");} else {
        if ((empty($libelle))|($categorie1==" ")|($categorie2==" ")) {echo "Remplir les champs obligatoires.";} else {
	$query="";
	$query ="UPDATE article SET libelle_article='$libelle' WHERE code_article=$code";
	$res=mysql_query($query,$db);
	$query ="UPDATE article SET cru='$cru' WHERE code_article=$code";
	$res=mysql_query($query,$db);
	$query ="UPDATE article SET categorie1='$categorie1' WHERE code_article=$code";
	$res=mysql_query($query,$db);
	$query ="UPDATE article SET categorie2='$categorie2' WHERE code_article=$code";
	$res=mysql_query($query,$db);
	$query ="UPDATE article SET categorie3='$categorie3' WHERE code_article=$code";
	$res=mysql_query($query,$db);
	$query ="UPDATE article SET prix='$prix' WHERE code_article=$code";
	$res=mysql_query($query,$db);
	//$query ="UPDATE article SET descriptif='$descriptif' WHERE code_article=$code";
	//$res=mysql_query($query,$db);
		
	echo "<table width=\"75%\" border=\"0\"><tr><td>Article: $libelle</td><td>"; 
	if ($res>0) {echo "Mise � jour effectu�es";} else {echo "Mise � jour non effectu�es";}
	echo "</td></tr></table>";
	
	echo ("<script language=\"javascript\">");
	echo ("parent.topFrame.document.location.href='maintenance_select.php?libelle=".$libelle."';");
	echo ("</SCRIPT>");
	}
}
}
if (!empty($BT_insert)) 
	{
	$query ="SELECT * from categories where (cat1='$categorie1')AND(cat2='$categorie2')AND(cat3='$categorie3')";
	$res=mysql_query($query,$db);
	$row=mysql_num_rows($res);
        if ($row<=0) {echo ("Cat�gories incoh�rentes   ");} else {
	if ((empty($libelle))|($categorie1==" ")|($categorie2==" ")) {echo "Remplir les champs obligatoires.";} else {
	$query="";
	$query="select libelle_article from article WHERE libelle_article='$libelle' AND cru='$cru'";
	$res = mysql_query($query,$db) or die ("requete1 invalide");
	$row=mysql_num_rows($res);
	if ($row<=0) {
	$date=date("Ymd");
	$maxnu = "select max(code_article) from article";
	$res  = mysql_query($maxnu,$db);
	$numax=0;
	if ($row = mysql_fetch_row($res)) {$numax=$row[0];$numax++;}
	
	$query="";
	$query ="INSERT INTO article VALUES('$numax','$libelle','$categorie1','$categorie2','$categorie3','$prix','$descriptif','$date','$cru')";
	$res = mysql_query($query,$db) or die ("requete invalide");
	
	echo "<table width=\"75%\" border=\"0\"><tr><td>Article: $libelle</td><td>"; 
	if ($res>0) {echo ("Insertion effectu�es avec succ�s");} else {echo ("L'insertion a �chou�e");}
	echo "</td></tr></table>";

	echo ("<script language=\"javascript\">");
	echo ("parent.topFrame.document.location.href='maintenance_select.php?libelle=".$libelle."';");
	echo ("</SCRIPT>");
	
	} else {echo ("L'article existe d�ja");}
	}
	}
	}
if (!empty($BT_delete)) 
	{
	if (empty($libelle)) {echo "Pour cette action, s�lectionner un article.";} else {
	$query ="DELETE FROM article WHERE code_article=$code";
	$res = mysql_query($query,$db);
	
	echo ("<table width=\"75%\" border=\"0\"><tr><td>Article: ".$libelle."</td><td>"); 
	if ($res>0) {echo ("Suppression effectu�e avec succ�s");} else {echo ("La suppression a �chou�e");}
	echo ("</td></tr></table>");
	
	echo ("<script language=\"javascript\">");
	echo ("parent.topFrame.document.location.href='maintenance_select.php?libelle=".$libelle."';");
	echo ("parent.bottomFrame.form1.libelle.value='';");
	echo ("parent.bottomFrame.form1.categorie1.value='';");
	echo ("parent.bottomFrame.form1.categorie2.value='';");
	echo ("parent.bottomFrame.form1.categorie3.value='';");
	echo ("parent.bottomFrame.form1.prix.value='';");
	//echo ("parent.bottomFrame.form1.descriptif.value='';");
	echo ("parent.bottomFrame.form1.code.value='';");
	echo ("</SCRIPT>");
	}
	}
mysql_close($db);

?>
</p></body></html>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Sans titre</title>
<script language="JavaScript" type="text/javascript" src="js_script.js">

</script>
<style type="text/css">
#divLinks   {position:absolute; left:0px; top:69px; visibility:hidden;}
#divLinks a {color:#336699; font-family:verdana,arial,helvetica,sans-serif; font-size:12px; font-weight:700;}
#divMessage {position:absolute; left:0px; width:654px; top:69px; visibility:hidden; z-index:2;}
</style>
<script language="JavaScript" type="text/javascript">

function lib_bwcheck()
{
	this.ver=navigator.appVersion
	this.agent=navigator.userAgent
	this.dom=document.getElementById?1:0
	this.opera5=(navigator.userAgent.indexOf("Opera")>-1 && document.getElementById)?1:0
	this.ie5=(this.ver.indexOf("MSIE 5")>-1 && this.dom && !this.opera5)?1:0; 
	this.ie6=(this.ver.indexOf("MSIE 6")>-1 && this.dom && !this.opera5)?1:0;
	this.ie4=(document.all && !this.dom && !this.opera5)?1:0;
	this.ie=this.ie4||this.ie5||this.ie6
	this.mac=this.agent.indexOf("Mac")>-1
	this.ns6=(this.dom && parseInt(this.ver) >= 5) ?1:0; 
	this.ns4=(document.layers && !this.dom)?1:0;
	this.bw=(this.ie6 || this.ie5 || this.ie4 || this.ns4 || this.ns6 || this.opera5)
	return this
}
var bw=new lib_bwcheck()

if(document.layers)
{
	scrX= innerWidth; scrY= innerHeight;
	onresize= function(){if(scrX!= innerWidth || scrY!= innerHeight){history.go(0)} }
}

msgFont= "arial,helvetiva"
msgFontSize= 10
msgFontColor="#000000"
msgWidth= "654"

messages=new Array()
messages[0]='<img src=images/nav/n_sr_0.gif width=655 height=14 border=0>'

messages[1]='<table border=0 cellspacing=0 cellpadding=0><tr><td nowrap><a href="liste_categorie.php?cat2=non millesim�s" target="body" onmouseover=document.n_01_01.src="images/nav/n_01_01_1.gif" onmouseout=document.n_01_01.src="images/nav/n_01_01_0.gif" onfocus="this.blur();"><img src=images/nav/n_01_01_0.gif width=116 height=14 border=0 name="n_01_01"></a><a href="liste_categorie.php?cat2=millesim�s" target="body" onmouseover=document.n_01_02.src="images/nav/n_01_02_1.gif" onmouseout=document.n_01_02.src="images/nav/n_01_02_0.gif" onfocus="this.blur();"><img src=images/nav/n_01_02_0.gif width=84 height=14 border=0 name="n_01_02"></a><a href="liste_categorie.php?cat2=les prestiges" target="body" onmouseover=document.n_01_03.src="images/nav/n_01_03_1.gif" onmouseout=document.n_01_03.src="images/nav/n_01_03_0.gif" onfocus="this.blur();"><img src=images/nav/n_01_03_0.gif width=103 height=14 name="n_01_03" border=0></a><a href="liste_categorie.php?cat2=Formats d\'exception" target="body" onmouseover=document.n_01_04.src="images/nav/n_01_04_1.gif" onmouseout=document.n_01_04.src="images/nav/n_01_04_0.gif" onfocus="this.blur();"><img src=images/nav/n_01_04_0.gif width=139 height=14 name="n_01_04" border=0></a><img src=images/nav/n_01_fin.gif width=214 height=14 alt= border=0></td></tr></table>'

messages[2]='<table border=0 cellspacing=0 cellpadding=0><tr><td nowrap><a href="liste_categorie.php?cat2=vins francais" target="body" onmouseover=document.n_02_01.src="images/nav/n_02_01_1.gif" onmouseout=document.n_02_01.src="images/nav/n_02_01_0.gif" onfocus="this.blur();"><img src=images/nav/n_02_01_0.gif width=107 height=14 border=0 name="n_02_01"></a><a href="liste_categorie.php?cat2=vins du monde" target="body" onmouseover=document.n_02_02.src="images/nav/n_02_02_1.gif" onmouseout=document.n_02_02.src="images/nav/n_02_02_0.gif" onfocus="this.blur();"><img src=images/nav/n_02_02_0.gif width=95 height=14 border=0 name="n_02_02"></a><img src=images/nav/n_02_fin.gif width=454 height=14 border=0></td></tr></table>'

messages[3]='<table border=0 cellspacing=0 cellpadding=0><tr><td nowrap><a href="liste_categorie.php?cat2=eaux de vie brunes" target="body" onmouseover=document.n_03_01.src="images/nav/n_03_01_1.gif" onmouseout=document.n_03_01.src="images/nav/n_03_01_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_01_0.gif width=138 height=14 border=0 name="n_03_01"></a><a href="liste_categorie.php?cat2=eaux de vie blanches" target="body" onmouseover=document.n_03_02.src="images/nav/n_03_02_1.gif" onmouseout=document.n_03_02.src="images/nav/n_03_02_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_02_0.gif width=147 height=14 border=0 name="n_03_02"></a><a href="liste_categorie.php?cat2=whiskies" target="body" onmouseover=document.n_03_03.src="images/nav/n_03_03_1.gif" onmouseout=document.n_03_03.src="images/nav/n_03_03_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_03_0.gif width=70 height=14 name="n_03_03" border=0></a><a href="liste_categorie.php?cat2=rhums" target="body" onmouseover=document.n_03_04.src="images/nav/n_03_04_1.gif" onmouseout=document.n_03_04.src="images/nav/n_03_04_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_04_0.gif width=52 height=14 name="n_03_04" border=0></a><a href="liste_categorie.php?cat2=vodkas" target="body" onmouseover=document.n_03_05.src="images/nav/n_03_05_1.gif" onmouseout=document.n_03_05.src="images/nav/n_03_05_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_05_0.gif width=59 height=14 name="n_03_05" border=0></a><a href="liste_categorie.php?cat2=portos" target="body" onmouseover=document.n_03_06.src="images/nav/n_03_06_1.gif" onmouseout=document.n_03_06.src="images/nav/n_03_06_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_06_0.gif width=58 height=14 name="n_03_06" border=0></a><a href="liste_categorie.php?cat2=divers" target="body" onmouseover=document.n_03_07.src="images/nav/n_03_07_1.gif" onmouseout=document.n_03_07.src="images/nav/n_03_07_0.gif" onfocus="this.blur();"><img src=images/nav/n_03_07_0.gif width=49 height=14 name="n_03_07" border=0></a><img src=images/nav/n_03_fin.gif width=82 height=14 alt= border=0></td></tr></table>'

messages[4]='<table border=0 cellspacing=0 cellpadding=0><tr><td nowrap><a href="liste_categorie.php?cat2=foie gras" target="body" onmouseover=document.n_04_01.src="images/nav/n_04_01_1.gif" onmouseout=document.n_04_01.src="images/nav/n_04_01_0.gif" onfocus="this.blur();"><img src=images/nav/n_04_01_0.gif width=80 height=14 border=0 name="n_04_01"></a><a href="liste_categorie.php?cat2=truffes" target="body" onmouseover=document.n_04_02.src="images/nav/n_04_02_1.gif" onmouseout=document.n_04_02.src="images/nav/n_04_02_0.gif" onfocus="this.blur();"><img src=images/nav/n_04_02_0.gif width=65 height=14 border=0 name="n_04_02"></a><a href="liste_categorie.php?cat2=caviars" target="body" onmouseover=document.n_04_03.src="images/nav/n_04_03_1.gif" onmouseout=document.n_04_03.src="images/nav/n_04_03_0.gif" onfocus="this.blur();"><img src=images/nav/n_04_03_0.gif width=64 height=14 name="n_04_03" border=0></a><a href="liste_categorie.php?cat2=huiles" target="body" onmouseover=document.n_04_04.src="images/nav/n_04_04_1.gif" onmouseout=document.n_04_04.src="images/nav/n_04_04_0.gif" onfocus="this.blur();"><img src=images/nav/n_04_04_0.gif width=56 height=14 name="n_04_04" border=0></a><a href="liste_categorie.php?cat2=vinaigre" target="body" onmouseover=document.n_04_05.src="images/nav/n_04_05_1.gif" onmouseout=document.n_04_05.src="images/nav/n_04_05_0.gif" onfocus="this.blur();"><img src=images/nav/n_04_05_0.gif width=70 height=14 name="n_04_05" border=0></a><img src=images/nav/n_04_separ.gif width=36 height=14 border=0><a href="B04_06.HTM" target="body" onmouseover=document.n_04_06.src="images/nav/n_04_06_1.gif" onmouseout=document.n_04_06.src="images/nav/n_04_06_0.gif" onfocus="this.blur();"><img src=images/nav/n_04_06_0.gif width=163 height=14 name="n_04_06" border=0></a><img src=images/nav/n_04_fin.gif width=121 height=14 alt= border=0></td></tr></table>'
</script>
<script language="JavaScript" src="js_nav.js"></script>
</head>

<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" background="images/f_nav.gif" bgcolor="#C0BCBB" style="background-repeat:no-repeat;">

<div id="onmouseout" style="position:absolute; z-index:1; left: 0px; top: 45px;">
<table border="0" cellspacing="0" cellpadding="0">
<tr onmouseout="changeText(0);">
	<td><a href="#" onfocus="this.blur();" onmouseout="changeText(0);"><img src="images/invisible.gif" width="700" height="45" alt="" border="0"></a></td>
</tr>
</table>
</a>
</div>

<div id="divLinks" style="position:absolute; z-index:2; left: 0px; top: 53px;">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td nowrap><a href="#" onmouseover="changeText(1);document.n_01.src='images/nav/n_01_1.gif';" onmouseout="document.n_01.src='images/nav/n_01_0.gif';" onfocus="this.blur();"><img src="images/nav/n_01_0.gif" width="86" height="16" alt="" border="0" name="n_01"></a><a href="#" onmouseover="changeText(2);document.n_02.src='images/nav/n_02_1.gif';" onmouseout="document.n_02.src='images/nav/n_02_0.gif';" onfocus="this.blur();"><img src="images/nav/n_02_0.gif" width="40" height="16" alt="" border="0" name="n_02"></a><a href="#" onmouseover="changeText(3);document.n_03.src='images/nav/n_03_1.gif';" onmouseout="document.n_03.src='images/nav/n_03_0.gif';" onfocus="this.blur();"><img src="images/nav/n_03_0.gif" width="63" height="16" alt="" border="0" name="n_03"></a><a href="#" onmouseover="changeText(4);document.n_04.src='images/nav/n_04_1.gif';" onmouseout="document.n_04.src='images/nav/n_04_0.gif';" onfocus="this.blur();"><img src="images/nav/n_04_0.gif" width="106" height="16" alt="" border="0" name="n_04"></a><img src="images/nav/n_fin.gif" width="360" height="16" alt="" border="0"></td>
</tr>
</table>
</div>
<div id="divMessage">
<img src="images/nav/n_sr_0.gif" width="655" height="14" alt="" border="0">
</div>
</body>
</html>

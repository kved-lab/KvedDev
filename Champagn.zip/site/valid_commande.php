<html>
<head>
<title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td colspan="2"><img src="images/titre/ts_05.gif" alt="" border="0"></td>
</tr>
<tr>
	<td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
	<td valign="top">
	<table border="0" cellspacing="0" cellpadding="3">
		<tr>
		<td valign="top">
		<p><img src="images/invisible.gif" width="400" height="1" alt="" border="0"><br>

<?
include("bib_functions.php");

$id=id_session($session);
$paiement=paiement_session($session);

$db = mysql_connect("phpMyAdmin.free.fr", "frederic.bertrand2", "ibik5jx9") or die ("impossible de se connecter");
mysql_select_db("frederic.bertrand2",$db);   

// -------- INSERTION EN-TETE DE COMMANDE -----------
$maxnu = "SELECT MAX(numcom) FROM et_commande";
$res0 = mysql_query($maxnu,$db);
$row = mysql_fetch_row($res0); 
$numax=$row[0];
$numax++;
$heure=date("G:i");
$date=date("d/m/Y");
if (empty($numcli)) {$numcli="?";}
$insercom_et="INSERT INTO et_commande VALUES ('$numax','$date','$heure','$id','0','0','$montant',' ','$paiement','$session')";
$res1=mysql_query($insercom_et,$db); 
if ($res1!=1) {echo "Probleme d'�criture: en-t�te de commande";}
	
// -------- INSERTION DETAIL DE COMMANDE -----------
$query ="SELECT * FROM panier WHERE idsession='$session'";
$res2=mysql_query($query,$db); 
while ($row=mysql_fetch_row($res2)) {
	$nucli=$row[0];
	$heure=$row[1];
	$date=$row[2];
	$nuart=$row[3];
	$qte=$row[4];
	$num=$row[5];
	$idsession=$row[6];
	$timestamp=$row[7];
	$insercom_dt="INSERT INTO dt_commande (heure,numcom,numart,qte,destocke,date,session)VALUES ('$heure','$numax','$nuart','$qte','0','$date','$session')";
	$res=mysql_query($insercom_dt,$db); 
	if ($res!=1) {echo "Probl�me d'�criture: d�tail commande";}
}
if (($res1!=0)&&($res!=0)) {
	$delete_pan="DELETE FROM panier WHERE idsession='$session'";
	$res3=mysql_query($delete_pan,$db); 
	if ($res3>0) {
		echo "Merci. Votre commande est bien partie. <br>Numero de commande: FFF".$numax;
		mail("fbertrand01@mageos.com","Commande sur vin-et-champagne.com"," Nouvelle commande de champagne. Montant: $montant, Pseudo: $id, Num�ro de commande: $numcom","");
		mail("mailinglist@vin-et-champagne.com","Commande sur vin-et-champagne.com"," Nouvelle commande de champagne. Montant: $montant, Pseudo: $id","");
		mail("vincent@vin-et-champagne.com","Commande sur vin-et-champagne.com"," Nouvelle commande de champagne. Montant: $montant, Pseudo: $id","");
		mail($mailfact,"Votre commande"," confirmation de commande par mail. Montant: $montant, Pseudo: $id, Num�ro de commande: $numcom","");
	  	
	} else {echo "probleme vide-panier";}
} 

mysql_close($db);
?>
</td></tr></table></td></tr></table>
</body>
</html>

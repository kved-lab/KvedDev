<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
        <title>contenu</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript">
<!--
function rand_number(n)
{
var x;
x=Math.round(Math.random()*100);
x%=n;
return x;
}

function boucle_coeur()
{
var i;
var intervalle=5000;
var img = new Array()
<!-- images -->
img[0]='<img src="pics/Coucher-de-soleil.gif" border=0 width=133 height=61 alt="">';
img[1]='<img src="pics/Hiver.gif" border=0 width=133 height=61 alt="">';
img[2]='<img src="pics/Nenuphars.gif" border=0 width=133 height=61 alt="">';
var nombre_total_images = 3; <!-- nombre d'images -->
var i=rand_number(nombre_total_images);
boucle.innerHTML=img[i];
setTimeout("boucle_coeur()",intervalle);
}
-->
</script>
</head>

<body leftmargin=5 topmargin=0 marginheight="0" marginwidth="5" bgcolor="#C0BCBB" background="images/f_body.gif" style="background-repeat:no-repeat;" bgproperties="FIXED" onload='boucle_coeur();'>
<table border="0" cellspacing="0" cellpadding="0">
<tr>
        <td colspan="2"><img src="images/titre/t_pres.gif" width="237" height="19" alt="" border="0"></td>
</tr>
<tr>
        <td background="images/f_cell_b_g.gif" valign="top"><img src="images/invisible.gif" width="5" height="150" alt="" border="0"></td>
        <td valign="top"><table border="0" cellspacing="0" cellpadding="3">
                <tr>
                        <td valign="top">
                        <blockquote>
                        <p><br>J�ai tendance � croire plus que mod�r�ment au hasard...  <br>
                        Il y � cinq ans je suis venu acheter une bouteille de Champagne (fra�che !) au 12 bis rue Parrot, un vendredi soir � 20h35...  <br>
                        J�ai tout de suite aim� ce lieu ... J�y suis revenu... un peu... puis de plus en plus souvent... aujourd�hui j�y suis tous les jours... il para�t m�me que j�y travaille...  je n�en suis pas vraiment certain... merci " Mr Hasard "...  merci de m�avoir permis de d�couvrir un monde convivial, festif, esth�tique, s�lectif...  enfin bref, passionn�.</p>

<p><b>Ce monde j�ai envie de vous y emmener, de vous le faire partager.</b></p></blockquote>
<p class="right"><i>Vincent CHAMBOUVET</i></p><p>&nbsp;</p></td>
                </tr>
        </table></td>
</tr>
<tr><td colspan="2" align='center' valign='top'>
<?php include('coeur.php'); ?>
</td></tr>
</table>
<br clear="all">

</body>
</html>
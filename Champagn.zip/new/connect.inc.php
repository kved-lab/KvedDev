<?php

$link = mysql_connect ("","cab_vin","zrvmgom5") or exit();
mysql_select_db (cab_vin) or exit();

?>
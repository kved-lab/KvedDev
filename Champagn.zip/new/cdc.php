<?php

         include('connect.inc.php');

         $result = mysql_query ("select titre_txt_module,text_txt_module from txt_module where type_txt_module = 'cdc' ") or exit();

         // creation du fichier

        $filename = "/opt/abso/users/cab/vin-et-champagne.com/web/new/txt/Qengine.txt";

        if(!($myfile = fopen($filename, "w")))

        {

                print("Error: ");

                print("'$filename' ne peut �tre cr��\n");

                exit;

        }

        //ecriture dans le fichier

        while ($array = mysql_fetch_array($result))

        {

                fputs($myfile, "Text,bold,color=0x000000,fontsize=10|");

                fputs($myfile, $array['titre_txt_module'] ."\n");

                fputs($myfile, "Text,color=0x000000,fontsize=9|");

                fputs($myfile, $array['text_txt_module'] ."\n");

                fputs($myfile, "line \n");

        }

        //fermeture du fichier

        fclose($myfile);

        include('deconnect.inc.php');
?>

<script language="JavaScript">
<!--
function rand_number(n)
{
var x;
x=Math.round(Math.random()*100);
x%=n;
return x;
}

function boucle_coeur()
{
var i;
var intervalle=5000;
var img = new Array()
<!-- images -->
img[0]='<img src="pics/Coucher-de-soleil.gif" border=0 width=133 height=61 alt="">';
img[1]='<img src="pics/Hiver.gif" border=0 width=133 height=61 alt="">';
img[2]='<img src="pics/Nenuphars.gif" border=0 width=133 height=61 alt="">';
var nombre_total_images = 3; <!-- nombre d'images -->
var i=rand_number(nombre_total_images);
boucle.innerHTML=img[i];
setTimeout("boucle_images()",intervalle);
}
-->
</script>




<div id='coup_de_coeur'>
<table width=464 border=0 cellpadding=0 cellspacing=0>
  <tr>
    <td colspan=5> <img src="images/coupdecoeur.gif" width=464 height=21></td>
    <td> <img src="images/espaceur.gif" width=1 height=21></td>
  </tr>
  <tr>
    <td colspan=3> <img src="images/coupdecoeur-03.gif" width=153 height=2></td>
    <td rowspan=3 bgcolor='#CDC9C9'>
        <applet CODE="djscroller.class"  Archive = djfiles.zip WIDTH=296 HEIGHT=60>

              <param name = scrollSpeed value = 100>

              <param name = scrollbar value = false>

              <param name = foregroundColor value =0xCDC9C9>

              <param name = backgroundColor value =0xCDC9C9>

              <param name = borderColor value = 0xCDC9C9>

              <param name = borderSize value = 0>

              <param name = frame value = _top>

              <param name = engine value = txt/Qengine.txt>

              <param name = splash0 value = "Coup de coeur">

              <param name = splashColor value = 0x000000>

    </applet>
        </td>
    <td rowspan=4> <img src="images/coupdecoeur-05.gif" width=15 height=72></td>
    <td> <img src="images/espaceur.gif" width=1 height=2></td>
  </tr>
  <tr>
    <td rowspan=3> <img src="images/coupdecoeur-06.gif" width=13 height=70></td>
    <td> <div id="boucle"></div></td>
    <td rowspan=3> <img src="images/coupdecoeur-08.gif" width=7 height=70></td>
    <td> <img src="images/espaceur.gif" width=1 height=61></td>
  </tr>
  <tr>
    <td rowspan=2> <img src="images/coupdecoeur-09.gif" width=133 height=9></td>
    <td> <img src="images/espaceur.gif" width=1 height=2></td>
  </tr>
  <tr>
    <td> <img src="images/coupdecoeur-10.gif" width=296 height=7></td>
    <td> <img src="images/espaceur.gif" width=1 height=7></td>
  </tr>
</table>
</div> 